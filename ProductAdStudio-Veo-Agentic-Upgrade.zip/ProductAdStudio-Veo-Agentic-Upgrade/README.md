# ProductAd Studio — Veo + Multi-Agent Build

Android Jetpack Compose app for planning and generating short-form product advertisements.

## What changed

- The creation flow starts with one natural-language brief, optional product details, and an optional product photo.
- Five separate Gemini 3.8 Flash calls perform brief analysis, concept development, copywriting, storyboard creation, and director/reviewer prompt preparation.
- The user can inspect the campaign brief, supplied facts/assumptions, creative direction, script, and storyboard before approving a render.
- Approved ads are generated with the Google Gemini API Veo model `veo-3.1-lite-generate-preview`, downloaded as a real MP4 into app-private storage, and opened in the editor.
- There is no stock-video/simulated-video fallback. Failed model calls are shown as errors and do not count against the five successful renders/day limit.
- Old bundled demo campaign rows are removed at startup; real user campaigns are preserved.

## Run locally

1. Import this project into Android Studio / the AI Studio Android workspace.
2. The provided starter archive contains `gradle-wrapper.properties` but does not include the `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar` wrapper launch files. If your IDE cannot sync, generate/restore a Gradle 9.3.1 wrapper using an installed Gradle distribution before building.
3. Add a valid `GEMINI_API_KEY` to `.env` or the AI Studio Secrets UI, then rebuild.
4. Use an API key/project that has access to Gemini 3.8 Flash and Veo 3.1 Lite with billing enabled.
5. Run on an Android device/emulator with network access.

**Verification status:** source was statically reviewed, but a full Android Gradle build and emulator test were not possible in the editing environment because the wrapper launch files, Gradle executable, and Android SDK were unavailable. Treat this as a project update that still needs a local Gradle sync/build before release.

## Render limits and cost

Veo 3.1 Lite is a paid API model; it is not free-tier video generation. At Google's published $0.05/second 720p rate, an 8-second render is approximately **$0.40** before taxes/currency conversion. Five successful renders are approximately **$2/day** or **$60 per 30 days** at the listed rate, excluding retries and model-price changes. See Google's current [Veo documentation](https://ai.google.dev/gemini-api/docs/veo) and [pricing](https://ai.google.dev/gemini-api/docs/pricing).

The current limit of five successful renders/day is device-local prototype enforcement. It resets by the device's local calendar day and can be bypassed by clearing app data/reinstalling or using another device. It is not an account-level commercial quota.

## Production security warning

This prototype calls Gemini/Veo directly from Android using `BuildConfig.GEMINI_API_KEY`; an API key packaged in an APK can be extracted. **Do not distribute this build publicly with a valuable unrestricted key.** For production, route Veo generation through a trusted backend or another secure server-side credential broker and enforce account-level quotas there. This is a security requirement, not currently implemented because this project uses a client-only generation path.

## Quality notes

The five-agent workflow creates a timecoded five-shot storyboard and instructs Veo to render a fast, intentional ad sequence. Veo is generative, so it may not follow every cut or product detail exactly; inspect each result before publishing. Uploaded product photography is passed as the generation's image input, not guaranteed perfect pixel-level packaging preservation. The generated MP4 is the Veo render; editor overlay controls remain app-side visual controls and are not yet composited into the exported MP4.
