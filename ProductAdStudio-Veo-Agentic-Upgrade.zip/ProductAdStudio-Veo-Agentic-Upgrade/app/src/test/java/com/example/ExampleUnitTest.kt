package com.example

import com.example.data.local.CampaignEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun campaignEntity_defaultsAreValid() {
        val campaign = CampaignEntity(
            id = "test-123",
            name = "Test Beauty Ad",
            prompt = "10s luxury skincare ad",
            productName = "Lume Stick",
            status = "COMPLETED",
            targetDuration = 10,
            cameraMotion = "Orbit 360°"
        )
        assertEquals("COMPLETED", campaign.status)
        assertEquals(10, campaign.targetDuration)
        assertEquals("Orbit 360°", campaign.cameraMotion)
        assertNotNull(campaign.headlineText)
        assertNotNull(campaign.ctaText)
        assertEquals(0xFFE2F952, campaign.ctaColorHex)
    }
}
