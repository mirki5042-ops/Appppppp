package com.example.data.remote

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import android.net.Uri
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

/** A visible milestone, not a dump of private model reasoning. */
data class AgenticStep(
    val title: String,
    val detail: String,
    val isCompleted: Boolean = false,
    val isCurrent: Boolean = false
)

data class PlanningResult(
    val summaryJson: String,
    val factsJson: String,
    val creativeDirectionJson: String,
    val scriptJson: String,
    val storyboardJson: String,
    val flowPrompt: String,
    val suggestedHeadline: String,
    val suggestedCta: String,
    val hookBadge: String,
    val subtitleText: String
)

/**
 * A small, explicit multi-agent workflow for turning a plain-language brief into a production plan.
 * Each specialist has a separate model call and consumes the prior specialist's output.
 * It deliberately fails closed instead of presenting fabricated copy as a successful AI result.
 */
class GeminiPlanningService(
    private val modelName: String = TEXT_MODEL
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .callTimeout(100, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val productPageClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .callTimeout(8, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun generateCompleteAdPlan(
        prompt: String,
        productName: String,
        productUrl: String?,
        objective: String,
        visualStyle: String,
        targetDuration: Int = 8,
        productBitmap: Bitmap? = null,
        onAgentStepUpdate: (List<AgenticStep>) -> Unit = {}
    ): PlanningResult {
        val apiKey = BuildConfig.GEMINI_API_KEY.trim()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            throw IllegalStateException(
                "Gemini is not configured. Add a valid GEMINI_API_KEY to the project's .env/AI Studio secrets, then rebuild."
            )
        }
        if (prompt.isBlank()) throw IllegalArgumentException("Describe the advertisement you want first.")

        val publicProductPageContext = fetchPublicProductPageContext(productUrl)
        val brief = JSONObject().apply {
            put("brief", prompt.trim())
            put("productName", productName.trim())
            put("productUrl", productUrl?.trim().orEmpty())
            put("publicProductPageMetadata", publicProductPageContext)
            put("objective", objective)
            put("visualStyle", visualStyle)
            put("durationSeconds", 8)
            put("aspectRatio", "9:16")
            put("uploadedProductPhotoProvided", productBitmap != null)
        }

        val steps = mutableListOf(
            AgenticStep("1 · Brief analyst", "Extracting audience, objective, product context, and evidence boundaries.", isCurrent = true),
            AgenticStep("2 · Creative strategist", "Finding one distinctive campaign idea and visual world."),
            AgenticStep("3 · Scriptwriter", "Writing the hook, concise voiceover, message, and call to action."),
            AgenticStep("4 · Storyboard artist", "Planning five clearly different shots within eight seconds."),
            AgenticStep("5 · Commercial director", "Building the Veo prompt and checking the ad for production risks.")
        )

        fun publish(currentIndex: Int, completedIndex: Int? = null, detail: String? = null) {
            if (completedIndex != null) {
                steps[completedIndex] = steps[completedIndex].copy(isCompleted = true, isCurrent = false)
            }
            steps.indices.forEach { index ->
                if (index == currentIndex) {
                    steps[index] = steps[index].copy(isCurrent = true, detail = detail ?: steps[index].detail)
                } else if (steps[index].isCurrent) {
                    steps[index] = steps[index].copy(isCurrent = false)
                }
            }
            onAgentStepUpdate(steps.toList())
        }

        onAgentStepUpdate(steps.toList())
        val analyst = callAgentJson(
            apiKey,
            """You are Agent 1: a senior advertising brief analyst. Convert the user's plain-language request into an accurate campaign brief. Distinguish user-supplied facts from assumptions. Any public website title/description is context only and is not evidence that a product claim is true. Never invent product ingredients, clinical claims, certifications, prices, offers, reviews, guarantees, performance results, or audience research. If a fact was not supplied, place it in assumptions or claimsToAvoid. Respond only as valid JSON with keys: briefSummary, coreMessage, targetAudience, desiredAction, productCategory, suppliedFacts (array), assumptions (array), claimsToAvoid (array), strategicTension. Keep fields concise and useful for production.""",
            "BRIEF INPUT:\n$brief",
            imageBitmap = productBitmap
        )
        publish(1, completedIndex = 0, detail = "Mapped the brief and separated supplied facts from assumptions.")

        val concept = callAgentJson(
            apiKey,
            """You are Agent 2: a distinctive creative strategist at a high-end advertising studio. Develop one coherent campaign concept, not a list of generic ideas. Use the user's brief and analyst output. Borrow craft principles from premium product commercials: meaningful visual metaphor, memorable opening image, tactile material detail, intentional color and light, motivated cuts, and a strong final product hero. Avoid generic 'viral' language and clichés. Do not invent product claims. Respond only as valid JSON with keys: conceptTitle, concept, rationale, visualWorld, mood, colorPalette (3-5 hex colors), lighting, cameraLanguage, transitionStyle, audioDirection.""",
            "BRIEF:\n$brief\nANALYST OUTPUT:\n$analyst"
        )
        publish(2, completedIndex = 1, detail = "Selected a campaign concept, visual language, lighting, and sound direction.")

        val script = callAgentJson(
            apiKey,
            """You are Agent 3: an experienced advertising copywriter. Write copy that can genuinely fit an 8-second vertical social ad. Use one hook, one clear benefit/message, and one action. Voiceover must be 12-18 words maximum, conversational, easy to speak in 8 seconds, and never introduce unsupported facts. Headline should be 2-6 words. Subtitle should not look like a legal or scientific claim unless the user supplied the evidence. The app adds on-screen text later, so keep screenText short and do not ask Veo to render typography. Return only JSON with keys: hookBadge, hook, voiceover, headline, subtitle, cta, scenes (exactly 5 objects with time, narration, screenText). Use these time ranges: 0.0-1.2s, 1.2-2.6s, 2.6-4.2s, 4.2-6.3s, 6.3-8.0s. No fake discount or free-shipping promise.""",
            "BRIEF:\n$brief\nANALYST:\n$analyst\nCREATIVE CONCEPT:\n$concept"
        )
        publish(3, completedIndex = 2, detail = "Wrote a concise script with a single message and clear CTA.")

        val storyboard = callAgentJson(
            apiKey,
            """You are Agent 4: a commercial storyboard artist and cinematographer. Create exactly five distinctly framed visual shots for one 8-second 9:16 portrait ad. They must read as a rapid, intentional edit with visible cut points, not one continuous shot and not five near-identical product angles. Keep the same product identity, packaging, palette, and lighting logic across every shot. Every shot must have a concrete subject action, camera move, composition, and transition. Use only the supplied brand facts. For a physical product, prioritize material texture, believable product physics, macro detail, use/context, and a clean hero packshot. Return only JSON with keys: scenes (exactly five objects with scene, time, shotType, action, camera, composition, productState, transition, soundCue). Use these exact intervals: 0.0-1.2s, 1.2-2.6s, 2.6-4.2s, 4.2-6.3s, 6.3-8.0s. Do not include generated text, subtitles, logos, interface mockups, or watermarks in the footage.""",
            "BRIEF:\n$brief\nCONCEPT:\n$concept\nSCRIPT:\n$script"
        )
        val scriptScenes = script.optJSONArray("scenes")
        val storyboardScenes = storyboard.optJSONArray("scenes")
        if (!hasFiveTimedScenes(scriptScenes) || !hasFiveTimedScenes(storyboardScenes)) {
            throw IOException("The creative agents returned an incomplete or mistimed five-shot script/storyboard. Please rebuild the plan; no video was generated.")
        }
        if (!hasRequiredFields(scriptScenes, listOf("narration")) ||
            !hasRequiredFields(storyboardScenes, listOf("shotType", "action", "camera", "composition", "transition"))) {
            throw IOException("One or more ad shots are missing production details. Rebuild the plan before spending a video render.")
        }
        publish(4, completedIndex = 3, detail = "Mapped five different shots with exact timing, camera direction, and transitions.")

        val director = callAgentJson(
            apiKey,
            """You are Agent 5: an award-winning commercial director and skeptical ad-quality reviewer preparing a prompt for Google Veo 3.1 Lite. Use the prior brief, concept, script, and storyboard to create one production-ready prompt. Return only JSON with keys: veoPrompt and qualityReview. qualityReview must be an object containing boolean fields claimsSafe, timingConfirmed, and productConsistency plus a concise notes string. Do not mark any field true unless you actually checked the prior agent outputs; if any check fails, revise the veoPrompt where possible and state the remaining problem. The prompt must be no more than 220 words, in English, and tell Veo to create a coherent 8-second 9:16 portrait commercial with five distinct visual shots cut at the supplied time intervals. State the product, scene actions, transitions, optics/camera moves, lighting, material/physics details, color palette and audio. If an uploaded product photo exists, treat it as the identity anchor and preserve its actual silhouette, packaging, colors, label placement and proportions; do not redesign it. If no photo exists, create a plausible product consistent with the brief, without imitating a real brand. Keep the ad visually rich but simple: each shot has one readable idea. Use the exact voiceover only if it fits naturally; otherwise preserve the script in the plan and use sound design. No legible in-frame text, extra dialogue, fake logos, fake claims, visual glitching, impossible product deformation, excessive particles, or one-take-only cinematography. Leave clean negative space for app-added copy and end on a stable, centered product hero shot. Quality review must flag unsupported claims, missing production details, or unclear timing.""",
            "BRIEF:\n$brief\nANALYST:\n$analyst\nCONCEPT:\n$concept\nSCRIPT:\n$script\nSTORYBOARD:\n$storyboard"
        )
        val review = director.optJSONObject("qualityReview")
            ?: throw IOException("The commercial director did not return the required quality review. Please rebuild the plan.")
        val reviewNotes = review.optString("notes", "Review notes were not supplied.")
        if (!review.optBoolean("claimsSafe", false) ||
            !review.optBoolean("timingConfirmed", false) ||
            !review.optBoolean("productConsistency", false)) {
            throw IOException("The director's quality gate did not pass: $reviewNotes. Review the brief or regenerate the plan before rendering.")
        }
        steps[4] = steps[4].copy(
            isCompleted = true,
            isCurrent = false,
            detail = "Director passed the claim-safety, shot-timing, and product-consistency checks."
        )
        onAgentStepUpdate(steps.toList())

        val finalSummary = JSONObject().apply {
            put("briefSummary", analyst.optString("briefSummary", prompt.trim()))
            put("coreMessage", analyst.optString("coreMessage", prompt.trim()))
            put("targetAudience", analyst.optString("targetAudience", "Audience inferred from the supplied brief"))
            put("advertisingAngle", concept.optString("concept", concept.optString("conceptTitle", "Product-led campaign")))
            put("desiredAction", analyst.optString("desiredAction", objective))
            put("conceptTitle", concept.optString("conceptTitle", "Campaign concept"))
            put("conceptRationale", concept.optString("rationale", ""))
        }
        val creativeWithConcept = JSONObject(concept.toString()).apply {
            put("agentReview", review.toString())
        }
        val facts = JSONObject().apply {
            put("suppliedFacts", analyst.optJSONArray("suppliedFacts") ?: JSONArray())
            put("assumptions", analyst.optJSONArray("assumptions") ?: JSONArray())
            put("claimsToAvoid", analyst.optJSONArray("claimsToAvoid") ?: JSONArray())
            put("productPhotoProvided", productBitmap != null)
        }

        val scenes = script.optJSONArray("scenes") ?: JSONArray()
        val scriptJson = JSONObject(script.toString()).apply {
            put("scenes", scenes)
            put("voiceover", script.optString("voiceover", ""))
            put("hook", script.optString("hook", ""))
        }
        val storyJson = JSONObject(storyboard.toString())
        val finalPrompt = director.optString("veoPrompt", "").trim()
        if (finalPrompt.isBlank()) throw IOException("The commercial director did not return a usable Veo prompt. Please retry.")
        if (finalPrompt.split(Regex("\\s+")).size > 240) {
            throw IOException("The commercial director returned an overlong production prompt. Rebuild the plan so Veo receives a focused brief.")
        }

        PlanningResult(
            summaryJson = finalSummary.toString(),
            factsJson = facts.toString(),
            creativeDirectionJson = creativeWithConcept.toString(),
            scriptJson = scriptJson.toString(),
            storyboardJson = storyJson.toString(),
            flowPrompt = finalPrompt,
            suggestedHeadline = script.optString("headline", "").ifBlank { productName.ifBlank { "Discover the difference" } },
            suggestedCta = script.optString("cta", "").ifBlank { "Learn more" },
            hookBadge = script.optString("hookBadge", "").ifBlank { "MADE TO STAND OUT" },
            subtitleText = script.optString("subtitle", "").ifBlank { analyst.optString("coreMessage", "") }
        )
    }

    private fun hasFiveTimedScenes(scenes: JSONArray?): Boolean {
        if (scenes == null || scenes.length() != 5) return false
        val expected = listOf(0.0 to 1.2, 1.2 to 2.6, 2.6 to 4.2, 4.2 to 6.3, 6.3 to 8.0)
        return expected.indices.all { index ->
            val time = scenes.optJSONObject(index)?.optString("time").orEmpty()
            val values = Regex("\\d+(?:\\.\\d+)?").findAll(time)
                .take(2).mapNotNull { it.value.toDoubleOrNull() }.toList()
            values.size == 2 && values[0] == expected[index].first && values[1] == expected[index].second
        }
    }

    private fun hasRequiredFields(scenes: JSONArray?, requiredFields: List<String>): Boolean {
        if (scenes == null || scenes.length() != 5) return false
        return (0 until scenes.length()).all { index ->
            val scene = scenes.optJSONObject(index) ?: return@all false
            requiredFields.all { field -> scene.optString(field).isNotBlank() && scene.optString(field) != "null" }
        }
    }

    /** Reads only public title/description metadata; failure is non-fatal and never treated as verified facts. */
    private suspend fun fetchPublicProductPageContext(rawUrl: String?): String = withContext(Dispatchers.IO) {
        val candidate = rawUrl?.trim().orEmpty()
        if (candidate.isBlank()) return@withContext ""
        val uri = try { Uri.parse(candidate) } catch (_: Exception) { return@withContext "" }
        if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) return@withContext ""
        try {
            val request = Request.Builder()
                .url(candidate)
                .header("User-Agent", "ProductAdStudio/1.0 (public product metadata)")
                .header("Accept", "text/html,application/xhtml+xml")
                .get()
                .build()
            productPageClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext ""
                val body = response.body ?: return@withContext ""
                if (body.contentLength() > MAX_PRODUCT_PAGE_BYTES) return@withContext ""
                val html = body.byteStream().use { input ->
                    val output = ByteArrayOutputStream()
                    val buffer = ByteArray(8 * 1024)
                    var total = 0L
                    while (true) {
                        val allowance = (MAX_PRODUCT_PAGE_BYTES + 1L - total).coerceAtMost(buffer.size.toLong()).toInt()
                        if (allowance <= 0) return@withContext ""
                        val count = input.read(buffer, 0, allowance)
                        if (count < 0) break
                        total += count
                        if (total > MAX_PRODUCT_PAGE_BYTES) return@withContext ""
                        output.write(buffer, 0, count)
                    }
                    String(output.toByteArray(), Charsets.UTF_8)
                }
                val metadata = linkedMapOf<String, String>()
                val metaTagRegex = Regex("<meta\\b[^>]*>", RegexOption.IGNORE_CASE)
                val attributeRegex = Regex("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))")
                metaTagRegex.findAll(html).forEach { match ->
                    val attrs = mutableMapOf<String, String>()
                    attributeRegex.findAll(match.value).forEach { attr ->
                        attrs[attr.groupValues[1].lowercase()] = attr.groupValues.drop(2).firstOrNull { it.isNotEmpty() }.orEmpty()
                    }
                    val key = (attrs["property"] ?: attrs["name"] ?: "").lowercase()
                    val value = attrs["content"].orEmpty().replace(Regex("<[^>]+>"), " ").trim()
                    if (key in listOf("og:title", "twitter:title", "og:description", "description", "twitter:description") && value.isNotBlank()) {
                        metadata.putIfAbsent(key, value)
                    }
                }
                val title = Regex("<title\\b[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                    .find(html)?.groupValues?.getOrNull(1)?.replace(Regex("<[^>]+>"), " ")?.trim()
                if (!title.isNullOrBlank()) metadata.putIfAbsent("page title", title)
                metadata.entries.joinToString("\n") { (key, value) -> "$key: ${value.take(450)}" }.take(2500)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not read public product page metadata: ${e.message}")
            ""
        }
    }

    private suspend fun callAgentJson(
        apiKey: String,
        systemPrompt: String,
        userInput: String,
        imageBitmap: Bitmap? = null
    ): JSONObject = withContext(Dispatchers.IO) {
            val parts = JSONArray().put(JSONObject().put("text", userInput))
            if (imageBitmap != null) {
                val imageBytes = ByteArrayOutputStream().use { output ->
                    imageBitmap.compress(Bitmap.CompressFormat.JPEG, 85, output)
                    output.toByteArray()
                }
                parts.put(JSONObject().put("inlineData", JSONObject().apply {
                    put("mimeType", "image/jpeg")
                    put("data", Base64.encodeToString(imageBytes, Base64.NO_WRAP))
                }))
            }
            val requestBody = JSONObject().apply {
                put("systemInstruction", JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", systemPrompt))
                ))
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", parts)
                }))
                put("generationConfig", JSONObject().apply {
                    // Gemini 3.8 uses thinkingLevel; legacy sampling parameters like temperature are not supported.
                    put("thinkingConfig", JSONObject().put("thinkingLevel", "medium"))
                    put("responseMimeType", "application/json")
                    put("maxOutputTokens", 1800)
                })
            }
            val request = Request.Builder()
                .url("$GEMINI_BASE_URL/models/$modelName:generateContent")
                .header("x-goog-api-key", apiKey)
                .header("Content-Type", "application/json")
                .post(requestBody.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val reason = JSONObjectOrEmpty(body).optJSONObject("error")?.optString("message").orEmpty()
                    Log.e(TAG, "$modelName returned HTTP ${response.code}: $reason")
                    throw IOException(apiErrorMessage(response.code, reason, "Gemini creative agent"))
                }
                val root = JSONObject(body)
                val candidates = root.optJSONArray("candidates")
                val text = candidates?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.let { parts ->
                        (0 until parts.length()).mapNotNull { index ->
                            parts.optJSONObject(index)?.optString("text")?.takeIf { it.isNotBlank() }
                        }.joinToString("\n")
                    }.orEmpty()
                if (text.isBlank()) throw IOException("Gemini returned an empty response. Please retry.")
                try {
                    JSONObject(extractJsonObject(text))
                } catch (e: Exception) {
                    Log.e(TAG, "Invalid JSON from $modelName: ${text.take(400)}", e)
                    throw IOException("The AI returned an invalid campaign plan. Please retry.")
                }
            }
        }

    private fun extractJsonObject(text: String): String {
        val cleaned = text.trim()
            .removePrefix("```json").removePrefix("```JSON").removePrefix("```")
            .removeSuffix("```").trim()
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        if (start < 0 || end <= start) throw IllegalArgumentException("No JSON object found")
        return cleaned.substring(start, end + 1)
    }

    private fun JSONObjectOrEmpty(value: String): JSONObject = try { JSONObject(value) } catch (_: Exception) { JSONObject() }

    private fun apiErrorMessage(code: Int, details: String, provider: String): String {
        val suffix = details.takeIf { it.isNotBlank() }?.let { " Details: $it" }.orEmpty()
        return when (code) {
            400 -> "$provider rejected the request. Check the brief and model configuration.$suffix"
            401, 403 -> "$provider API key is invalid or lacks access. Check GEMINI_API_KEY and API access.$suffix"
            429 -> "$provider rate limit reached. Wait a little before retrying.$suffix"
            in 500..599 -> "$provider is temporarily unavailable. Try again in a moment.$suffix"
            else -> "$provider request failed (HTTP $code).$suffix"
        }
    }

    companion object {
        const val TEXT_MODEL = "gemini-3.8-flash"
        const val GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
        private const val TAG = "AdCreativeOrchestrator"
        private const val MAX_PRODUCT_PAGE_BYTES = 750_000L
    }
}
