package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Studio Dark Palette
val StudioBackground = Color(0xFF0A0C10)
val StudioSurface = Color(0xFF14171F)
val StudioSurfaceElevated = Color(0xFF1D222D)
val StudioSurfaceCard = Color(0xFF181C25)
val StudioBorder = Color(0xFF282E3C)
val StudioBorderHighlight = Color(0xFF3B4356)

// Accent Accents from Reference Designs
val StudioAccentLime = Color(0xFFE2F952)      // Bright action button & pill badge
val StudioAccentLavender = Color(0xFFC8B6FF)  // Secondary tag & creative chips
val StudioAccentCyan = Color(0xFF38BDF8)      // Video & timeline markers
val StudioAccentRose = Color(0xFFFB7185)      // Warning / discard badge
val StudioAccentAmber = Color(0xFFFBBF24)     // Star ratings & highlights

// Text & Content Tokens
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextOnAccent = Color(0xFF0A0C10)
