package com.example.data.repository

import com.example.data.local.CampaignDao
import com.example.data.local.CampaignEntity
import kotlinx.coroutines.flow.Flow

class CampaignRepository(private val dao: CampaignDao) {
    val allCampaigns: Flow<List<CampaignEntity>> = dao.getAllCampaigns()

    fun observeCampaign(id: String): Flow<CampaignEntity?> = dao.observeCampaignById(id)

    suspend fun getCampaign(id: String): CampaignEntity? = dao.getCampaignById(id)

    suspend fun saveCampaign(campaign: CampaignEntity) {
        dao.insertCampaign(campaign)
    }

    suspend fun deleteCampaign(id: String) {
        dao.deleteById(id)
    }

    /** Removes obsolete demo campaigns created by older app versions, without touching real user work. */
    suspend fun deleteBundledPresets() {
        dao.deleteBundledPresets()
    }
}
