package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CampaignEntity
import com.example.ui.theme.StudioAccentCyan
import com.example.ui.theme.StudioAccentLavender
import com.example.ui.theme.StudioAccentLime
import com.example.ui.theme.StudioAccentRose
import com.example.ui.theme.StudioBackground
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurfaceCard
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import org.json.JSONArray
import org.json.JSONObject

@Composable
fun PlanningScreen(
    campaign: CampaignEntity,
    onBack: () -> Unit,
    onApproveAndContinue: (CampaignEntity) -> Unit
) {
    BackHandler(onBack = onBack)
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("1. Understanding", "2. Brand Facts", "3. Creative Direction", "4. Script", "5. Storyboard")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("planning_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = campaign.productName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = "${campaign.targetDuration}s Vertical • ${campaign.visualStyle}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = StudioAccentLime
                    )
                )
            }
        }

        // Stage Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = StudioSurfaceElevated,
            contentColor = StudioAccentLime,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = StudioAccentLime
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) StudioAccentLime else TextSecondary
                        )
                    }
                )
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (selectedTab) {
                0 -> UnderstandingTab(campaign)
                1 -> FactsTab(campaign)
                2 -> CreativeDirectionTab(campaign)
                3 -> ScriptTab(campaign)
                4 -> StoryboardTab(campaign)
            }
        }

        // Bottom Approval Bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard),
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
        ) {
            Text(
                text = "One 8-second, 720p Veo render · approx. \$0.40 at Google's listed Veo Lite rate",
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, start = 20.dp, end = 20.dp),
                color = TextMuted,
                fontSize = 10.sp
            )
            Button(
                onClick = { onApproveAndContinue(campaign) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .height(54.dp)
                    .testTag("approve_plan_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudioAccentLime,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(27.dp)
            ) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Approve & render with Veo", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun UnderstandingTab(campaign: CampaignEntity) {
    val summaryObj = remember(campaign.summaryJson) {
        try {
            JSONObject(campaign.summaryJson ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PlanningInfoCard(
                title = "CORE MESSAGE",
                content = summaryObj.optString("coreMessage").ifBlank { "Not specified in the brief." },
                icon = Icons.Default.AutoAwesome,
                accentColor = StudioAccentLime
            )
        }
        item {
            PlanningInfoCard(
                title = "TARGET AUDIENCE",
                content = summaryObj.optString("targetAudience").ifBlank { "The audience has not been established yet." },
                icon = Icons.Default.Psychology,
                accentColor = StudioAccentLavender
            )
        }
        item {
            PlanningInfoCard(
                title = "ADVERTISING ANGLE",
                content = summaryObj.optString("advertisingAngle").ifBlank { "No advertising angle was returned by the planning agents." },
                icon = Icons.Default.Palette,
                accentColor = StudioAccentCyan
            )
        }
        item {
            PlanningInfoCard(
                title = "DESIRED ACTION",
                content = summaryObj.optString("desiredAction").ifBlank { "Not specified in the brief." },
                icon = Icons.Default.CheckCircle,
                accentColor = StudioAccentLime
            )
        }
    }
}

@Composable
fun FactsTab(campaign: CampaignEntity) {
    val factsObj = remember(campaign.factsJson) {
        try { JSONObject(campaign.factsJson ?: "{}") } catch (_: Exception) { JSONObject() }
    }
    fun readArray(key: String): List<String> {
        val arr = factsObj.optJSONArray(key) ?: return emptyList()
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() && it != "null" }
    }
    val supplied = remember(factsObj) { readArray("suppliedFacts") }
    val assumptions = remember(factsObj) { readArray("assumptions") }
    val claimsToAvoid = remember(factsObj) { readArray("claimsToAvoid") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            FactsListSection(
                title = "FACTS FOUND IN YOUR BRIEF",
                items = supplied,
                emptyMessage = "No product facts were supplied. The ad will avoid specific performance, ingredient, certification, pricing, and review claims.",
                accent = StudioAccentLime
            )
        }
        item {
            FactsListSection(
                title = "ASSUMPTIONS TO CONFIRM",
                items = assumptions,
                emptyMessage = "No additional assumptions were identified.",
                accent = Color(0xFFFFB74D)
            )
        }
        item {
            FactsListSection(
                title = "CLAIMS TO AVOID",
                items = claimsToAvoid,
                emptyMessage = "No specific risky claims were flagged. Verify all product claims before publishing.",
                accent = StudioAccentRose
            )
        }
    }
}

@Composable
private fun FactsListSection(
    title: String,
    items: List<String>,
    emptyMessage: String,
    accent: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(
                letterSpacing = 1.2.sp,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        )
        if (items.isEmpty()) {
            Text(emptyMessage, color = TextSecondary, fontSize = 12.sp, lineHeight = 18.sp)
        } else {
            items.forEach { fact ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(StudioSurfaceCard)
                        .border(1.dp, StudioBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
                    Spacer(Modifier.width(10.dp))
                    Text(fact, color = TextPrimary, fontSize = 13.sp, lineHeight = 18.sp)
                }
            }
        }
    }
}

@Composable
fun CreativeDirectionTab(campaign: CampaignEntity) {
    val creativeObj = remember(campaign.creativeDirectionJson) {
        try {
            JSONObject(campaign.creativeDirectionJson ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PlanningInfoCard(
                title = "MOOD & AESTHETIC",
                content = creativeObj.optString("mood", campaign.visualStyle),
                icon = Icons.Default.Palette,
                accentColor = StudioAccentLavender
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "RECOMMENDED COLOR PALETTE",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    val palette = remember(creativeObj.toString()) {
                        val array = creativeObj.optJSONArray("colorPalette") ?: creativeObj.optJSONArray("palette")
                        if (array == null) emptyList() else (0 until array.length()).map { array.optString(it) }
                            .filter { it.matches(Regex("#[0-9A-Fa-f]{6}")) }.take(5)
                    }
                    if (palette.isEmpty()) {
                        Text("No palette was supplied by the creative agent.", color = TextSecondary, fontSize = 12.sp)
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            palette.forEach { hex ->
                                ColorSwatch(Color(android.graphics.Color.parseColor(hex)), hex.uppercase())
                            }
                        }
                    }
                }
            }
        }

        item {
            PlanningInfoCard(
                title = "LIGHTING DIRECTION",
                content = creativeObj.optString("lighting").ifBlank { "No lighting direction was returned." },
                icon = Icons.Default.AutoAwesome,
                accentColor = StudioAccentLime
            )
        }

        item {
            PlanningInfoCard(
                title = "CAMERA LANGUAGE",
                content = creativeObj.optString("cameraLanguage").ifBlank { "No camera direction was returned." },
                icon = Icons.Default.ViewCarousel,
                accentColor = StudioAccentCyan
            )
        }
    }
}

@Composable
fun ColorSwatch(color: Color, hexLabel: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(color)
                .border(1.dp, StudioBorder, CircleShape)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(hexLabel, color = TextMuted, fontSize = 10.sp)
    }
}

@Composable
fun ScriptTab(campaign: CampaignEntity) {
    val scriptObj = remember(campaign.scriptJson) {
        try {
            JSONObject(campaign.scriptJson ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
    }

    val scenes = remember(scriptObj) {
        val list = mutableListOf<JSONObject>()
        val arr = scriptObj.optJSONArray("scenes")
        if (arr != null) {
            for (i in 0 until arr.length()) list.add(arr.optJSONObject(i))
        }
        list
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PlanningInfoCard(
                title = "HOOK SENTENCE (FIRST 3 SECONDS)",
                content = scriptObj.optString("hook").ifBlank { "No hook was returned by the scriptwriter." },
                icon = Icons.Default.RecordVoiceOver,
                accentColor = StudioAccentLime
            )
        }

        if (scenes.isEmpty()) {
            item {
                Text(
                    "No script scenes are available. Rebuild the plan to ask the scriptwriter agent to try again.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            }
        } else {
            items(scenes) { scene ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = scene.optString("time", "Scene"),
                                color = StudioAccentLime,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            val screenText = scene.optString("screenText")
                            if (screenText.isNotBlank()) {
                                Text(
                                    text = "Overlay: $screenText",
                                    color = StudioAccentLavender,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Voiceover: \"${scene.optString("narration", "")}\"",
                            color = TextPrimary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StoryboardTab(campaign: CampaignEntity) {
    val storyboardObj = remember(campaign.storyboardJson) {
        try {
            JSONObject(campaign.storyboardJson ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
    }

    val scenes = remember(storyboardObj) {
        val list = mutableListOf<JSONObject>()
        val arr = storyboardObj.optJSONArray("scenes")
        if (arr != null) {
            for (i in 0 until arr.length()) list.add(arr.optJSONObject(i))
        }
        list
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (scenes.isEmpty()) {
            item {
                Text(
                    "No storyboard scenes are available. Rebuild the plan to ask the storyboard agent to try again.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            }
        } else {
            items(scenes) { scene ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "SCENE ${scene.optInt("scene", 1)} · ${scene.optString("time")}",
                                color = StudioAccentCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = scene.optString("camera", "Camera direction not supplied"),
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = scene.optString("action", "No shot action supplied."),
                            color = TextPrimary,
                            fontSize = 13.sp
                        )
                        val composition = scene.optString("composition")
                        val transition = scene.optString("transition")
                        if (composition.isNotBlank() || transition.isNotBlank()) {
                            Spacer(modifier = Modifier.height(5.dp))
                            Text(
                                text = listOf(composition, transition).filter { it.isNotBlank() }.joinToString(" · "),
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlanningInfoCard(
    title: String,
    content: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = content,
                color = TextPrimary,
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }
    }
}
