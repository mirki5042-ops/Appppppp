package com.example.ui.screens

import android.media.MediaPlayer
import android.net.Uri
import android.widget.VideoView
import com.example.ui.components.VideoPlayerView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.CampaignEntity
import com.example.ui.theme.StudioAccentCyan
import com.example.ui.theme.StudioAccentLavender
import com.example.ui.theme.StudioAccentLime
import com.example.ui.theme.StudioAccentRose
import com.example.ui.theme.StudioBackground
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurfaceCard
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.CampaignClipSequencer
import kotlinx.coroutines.delay
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoEditorScreen(
    campaign: CampaignEntity,
    onBack: () -> Unit,
    onSaveOverlays: (
        headline: String,
        ctaText: String,
        brandName: String,
        hookBadge: String,
        subtitleText: String,
        ctaColor: Long,
        textColor: Long,
        endCardDuration: Float,
        showEndCard: Boolean,
        showHookBadge: Boolean,
        showSubtitle: Boolean
    ) -> Unit,
    onSwapFootage: (newVideoUri: String, newProductImageUri: String?) -> Unit,
    onGoToExport: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current

    var headline by remember(campaign.id) { mutableStateOf(campaign.headlineText) }
    var ctaText by remember(campaign.id) { mutableStateOf(campaign.ctaText) }
    var brandName by remember(campaign.id) { mutableStateOf(campaign.brandName) }
    var hookBadge by remember(campaign.id) { mutableStateOf(campaign.hookBadge) }
    var subtitleText by remember(campaign.id) { mutableStateOf(campaign.subtitleText) }
    var ctaColorHex by remember(campaign.id) { mutableStateOf(campaign.ctaColorHex) }
    var textColorHex by remember(campaign.id) { mutableStateOf(campaign.textColorHex) }
    var endCardDuration by remember(campaign.id) { mutableFloatStateOf(campaign.endCardDurationSeconds) }
    var showEndCard by remember(campaign.id) { mutableStateOf(campaign.showEndCard) }
    var showHookBadge by remember(campaign.id) { mutableStateOf(campaign.showHookBadge) }
    var showSubtitle by remember(campaign.id) { mutableStateOf(campaign.showSubtitle) }

    var isPlaying by remember { mutableStateOf(true) }
    var isMuted by remember { mutableStateOf(false) }
    var videoViewRef by remember { mutableStateOf<VideoView?>(null) }
    var mediaPlayerRef by remember { mutableStateOf<MediaPlayer?>(null) }

    // Multi-Scene Clipping System
    val scenes = remember(campaign) { CampaignClipSequencer.getScenesForCampaign(context, campaign) }
    val playlistUris = remember(scenes) { scenes.map { it.videoUri } }
    val storyboardShots = remember(campaign.storyboardJson) {
        val parsed = mutableListOf<JSONObject>()
        try {
            val shotArray = JSONObject(campaign.storyboardJson ?: "{}").optJSONArray("scenes")
            if (shotArray != null) {
                for (index in 0 until shotArray.length()) {
                    shotArray.optJSONObject(index)?.let(parsed::add)
                }
            }
        } catch (_: Exception) {
            // Leave the storyboard empty and explain that in the UI; never substitute demo shots.
        }
        parsed
    }

    var isMontageMode by remember { mutableStateOf(true) }
    var activeSceneIndex by remember { mutableIntStateOf(0) }
    val currentScene = scenes.getOrElse(activeSceneIndex) { scenes.first() }

    var selectedEditorTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Script & CTA", "Shot Plan", "Replace Video", "Brand & Colors")

    // Video clip picker for uploading custom footage
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onSwapFootage(uri.toString(), null)
        }
    }

    // Debounce auto-saving overlays to prevent Room query storms
    LaunchedEffect(headline, ctaText, brandName, hookBadge, subtitleText, ctaColorHex, textColorHex, endCardDuration, showEndCard, showHookBadge, showSubtitle) {
        delay(400)
        onSaveOverlays(
            headline,
            ctaText,
            brandName,
            hookBadge,
            subtitleText,
            ctaColorHex,
            textColorHex,
            endCardDuration,
            showEndCard,
            showHookBadge,
            showSubtitle
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Top App Bar with Quick Actions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("video_editor_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Commercial Ad Director",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = if (scenes.size == 1) "Complete Veo ad · 8 seconds" else if (isMontageMode) "Full campaign montage" else "Scene ${activeSceneIndex + 1}: ${currentScene.title}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = StudioAccentLime,
                        fontSize = 11.sp
                    )
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = {
                        isMuted = !isMuted
                        mediaPlayerRef?.let { mp ->
                            try {
                                if (isMuted) mp.setVolume(0f, 0f) else mp.setVolume(1f, 1f)
                            } catch (e: Exception) {
                                // Ignore
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeMute else Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Mute",
                        tint = if (isMuted) StudioAccentRose else StudioAccentLime
                    )
                }

                Button(
                    onClick = onGoToExport,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioAccentLime, contentColor = Color.Black),
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(34.dp).testTag("editor_export_shortcut")
                ) {
                    Text("Export", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(12.dp))
                }
            }
        }

        // Quick Scene Clipping Timeline Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = isMontageMode,
                onClick = { isMontageMode = true },
                label = { Text("🎬 Full Ad", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = StudioAccentLime,
                    selectedLabelColor = Color.Black,
                    containerColor = StudioSurfaceElevated,
                    labelColor = TextSecondary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    borderColor = if (isMontageMode) StudioAccentLime else StudioBorder,
                    enabled = true,
                    selected = isMontageMode
                )
            )

            if (scenes.size > 1) scenes.forEachIndexed { idx, sc ->
                FilterChip(
                    selected = !isMontageMode && activeSceneIndex == idx,
                    onClick = {
                        isMontageMode = false
                        activeSceneIndex = idx
                    },
                    label = { Text("Scene ${idx + 1}", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = StudioAccentCyan,
                        selectedLabelColor = Color.Black,
                        containerColor = StudioSurfaceElevated,
                        labelColor = TextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = if (!isMontageMode && activeSceneIndex == idx) StudioAccentCyan else StudioBorder,
                        enabled = true,
                        selected = !isMontageMode && activeSceneIndex == idx
                    )
                )
            }
        }

        // Live 9:16 Vertical Video Canvas with Multi-Clip Sync
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 22.dp, vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxSize()
                    .aspectRatio(9f / 16f, matchHeightConstraintsFirst = true)
                    .clip(RoundedCornerShape(22.dp))
                    .border(1.5.dp, if (isMontageMode) StudioAccentLime else StudioAccentCyan, RoundedCornerShape(22.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.Black)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable {
                            videoViewRef?.let { vv ->
                                try {
                                    if (vv.isPlaying) {
                                        vv.pause()
                                        isPlaying = false
                                    } else {
                                        vv.start()
                                        isPlaying = true
                                    }
                                } catch (e: Exception) {
                                    // Ignore
                                }
                            }
                        }
                ) {
                    // Video Player Layer
                    VideoPlayerView(
                        videoUriString = if (!isMontageMode) playlistUris.getOrNull(activeSceneIndex) else null,
                        playlistUris = playlistUris,
                        currentSceneIndex = activeSceneIndex,
                        isMontageMode = isMontageMode,
                        onSceneAdvanced = { nextIndex ->
                            activeSceneIndex = nextIndex
                        },
                        fallbackImageUri = campaign.productImageUri,
                        isMuted = isMuted,
                        onPlayerReady = { mp, vv ->
                            mediaPlayerRef = mp
                            videoViewRef = vv
                            isPlaying = true
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Cinematic Gradient Vignette
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Black.copy(alpha = 0.55f),
                                        Color.Transparent,
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.80f)
                                    )
                                )
                            )
                    )

                    // Top Brand Badge & Clipping Time Pill
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(0.8.dp, StudioBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(Color(ctaColorHex))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = brandName,
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Replay & Clipping Label
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                color = StudioSurfaceElevated.copy(alpha = 0.85f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(0.6.dp, StudioBorder)
                            ) {
                                Text(
                                    text = if (isMontageMode) "FULL AD · 8S" else currentScene.timingLabel,
                                    color = StudioAccentLime,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }

                            Surface(
                                color = Color.Black.copy(alpha = 0.65f),
                                shape = CircleShape,
                                modifier = Modifier.clickable {
                                    try {
                                        videoViewRef?.seekTo(0)
                                        videoViewRef?.start()
                                        isPlaying = true
                                    } catch (e: Exception) {
                                        // Ignore
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Replay,
                                    contentDescription = "Replay",
                                    tint = TextPrimary,
                                    modifier = Modifier.padding(6.dp).size(14.dp)
                                )
                            }
                        }
                    }

                    // Bottom Dynamic Ad Overlays
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 14.dp, vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // 1. Hook Eyebrow Badge
                        if (showHookBadge) {
                            val badgeText = if (isMontageMode && activeSceneIndex > 0) currentScene.hookBadge else hookBadge
                            Surface(
                                color = Color.Black.copy(alpha = 0.8f),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, StudioAccentLime)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = badgeText,
                                        color = StudioAccentLime,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        // 2. High-Converting Headline
                        val displayHeadline = if (isMontageMode && activeSceneIndex > 0) currentScene.headline else headline
                        Text(
                            text = displayHeadline,
                            color = Color(textColorHex),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            lineHeight = 21.sp,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )

                        // 3. Sensory Subtitle / Bullet Proof
                        if (showSubtitle) {
                            val displaySub = if (isMontageMode && activeSceneIndex > 0) currentScene.subtitle else subtitleText
                            if (displaySub.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = displaySub,
                                    color = Color(0xFFD1D5DB),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // 4. CTA Pill Button
                        Surface(
                            color = Color(ctaColorHex),
                            shape = RoundedCornerShape(22.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = ctaText,
                                    color = Color.Black,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom Controls Drawer
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard),
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
            border = BorderStroke(1.dp, StudioBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                // Tab Header
                TabRow(
                    selectedTabIndex = selectedEditorTab,
                    containerColor = Color.Transparent,
                    contentColor = StudioAccentLime,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedEditorTab]),
                            color = StudioAccentLime,
                            height = 2.dp
                        )
                    },
                    divider = {}
                ) {
                    tabs.forEachIndexed { idx, title ->
                        Tab(
                            selected = selectedEditorTab == idx,
                            onClick = { selectedEditorTab = idx },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 10.sp,
                                    fontWeight = if (selectedEditorTab == idx) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedEditorTab == idx) StudioAccentLime else TextSecondary
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Scrollable Controls Drawer Content
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    when (selectedEditorTab) {
                        0 -> {
                            // TAB 0: 5-Phase Ad Copy
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = headline,
                                    onValueChange = { headline = it },
                                    label = { Text("Hook Headline (Thumb-Stop)", color = TextSecondary) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("headline_input"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = StudioAccentLime,
                                        unfocusedBorderColor = StudioBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    )
                                )

                                OutlinedTextField(
                                    value = ctaText,
                                    onValueChange = { ctaText = it },
                                    label = { Text("Call to Action (CTA) Button", color = TextSecondary) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("cta_text_input"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = StudioAccentLime,
                                        unfocusedBorderColor = StudioBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    )
                                )

                                OutlinedTextField(
                                    value = hookBadge,
                                    onValueChange = { hookBadge = it },
                                    label = { Text("Viral Eyebrow Tag", color = TextSecondary) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = StudioAccentLime,
                                        unfocusedBorderColor = StudioBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    )
                                )

                                OutlinedTextField(
                                    value = subtitleText,
                                    onValueChange = { subtitleText = it },
                                    label = { Text("Sensory Metaphor / Proof Subtitle", color = TextSecondary) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = StudioAccentLime,
                                        unfocusedBorderColor = StudioBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    )
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Display Hook Eyebrow Badge", color = TextPrimary, fontSize = 12.sp)
                                    Switch(
                                        checked = showHookBadge,
                                        onCheckedChange = { showHookBadge = it },
                                        colors = SwitchDefaults.colors(checkedThumbColor = StudioAccentLime)
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Display Subtitle / Proof Line", color = TextPrimary, fontSize = 12.sp)
                                    Switch(
                                        checked = showSubtitle,
                                        onCheckedChange = { showSubtitle = it },
                                        colors = SwitchDefaults.colors(checkedThumbColor = StudioAccentLime)
                                    )
                                }
                            }
                        }
                        1 -> {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = "APPROVED FIVE-SHOT STORYBOARD",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "This is the director's shot plan for the complete Veo MP4. Individual shots are not separate source clips in the current generator.",
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp
                                )
                                if (storyboardShots.isEmpty()) {
                                    Text(
                                        text = "No storyboard shots are available. Return to planning and rebuild the creative plan.",
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                } else {
                                    storyboardShots.forEachIndexed { index, shot ->
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .border(1.dp, StudioBorder, RoundedCornerShape(12.dp)),
                                            colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard)
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(5.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "SHOT ${index + 1} · ${shot.optString("time", "Timing not set")}",
                                                        fontWeight = FontWeight.Bold,
                                                        color = StudioAccentLime,
                                                        fontSize = 11.sp
                                                    )
                                                    Text(
                                                        text = shot.optString("shotType", ""),
                                                        color = StudioAccentCyan,
                                                        fontSize = 10.sp
                                                    )
                                                }
                                                Text(
                                                    text = shot.optString("action", "Shot action not supplied."),
                                                    color = TextPrimary,
                                                    fontSize = 12.sp,
                                                    lineHeight = 17.sp
                                                )
                                                val camera = shot.optString("camera")
                                                val composition = shot.optString("composition")
                                                val transition = shot.optString("transition")
                                                val direction = listOf(camera, composition, transition)
                                                    .filter { it.isNotBlank() }
                                                    .joinToString(" · ")
                                                if (direction.isNotBlank()) {
                                                    Text(
                                                        text = direction,
                                                        color = TextSecondary,
                                                        fontSize = 10.sp,
                                                        lineHeight = 14.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        2 -> {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = "REPLACE THE GENERATED VIDEO",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Choose a real video from your gallery to use instead of the Veo render. This replaces the whole source video; it does not insert separate B-roll shots into the ad.",
                                    color = TextSecondary,
                                    fontSize = 12.sp,
                                    lineHeight = 18.sp
                                )
                                OutlinedButton(
                                    onClick = {
                                        videoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth().height(46.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, StudioAccentCyan)
                                ) {
                                    Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = StudioAccentCyan, modifier = Modifier.size(17.dp))
                                    Spacer(modifier = Modifier.width(7.dp))
                                    Text("Choose a video from Gallery", fontSize = 12.sp, color = StudioAccentCyan)
                                }
                                Text(
                                    text = "Current source: ${if (campaign.importedVideoUri.orEmpty().startsWith("file://") && campaign.importedVideoUri.orEmpty().contains("generated_ads")) "Veo-generated ad" else "User-selected or imported video"}",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        3 -> {
                            // TAB 3: BRAND & COLORS
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = brandName,
                                    onValueChange = { brandName = it },
                                    label = { Text("Brand / Creator Label", color = TextSecondary) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = StudioAccentLime,
                                        unfocusedBorderColor = StudioBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    )
                                )

                                Text("CTA Button Color Palette", color = TextSecondary, fontSize = 11.sp)
                                val ctaColorOptions = listOf(
                                    0xFFE2F952 to "Neon Lime",
                                    0xFF00E5FF to "Cyan Glow",
                                    0xFFFF3366 to "Hot Pink",
                                    0xFFFFD700 to "Luxury Gold",
                                    0xFF9D4EDD to "Electric Purple",
                                    0xFFFFFFFF to "Pure White"
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ctaColorOptions.forEach { (colorVal, _) ->
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(CircleShape)
                                                .background(Color(colorVal))
                                                .border(
                                                    2.dp,
                                                    if (ctaColorHex == colorVal) Color.White else Color.Transparent,
                                                    CircleShape
                                                )
                                                .clickable { ctaColorHex = colorVal }
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Text("End Card Duration: ${String.format("%.1f", endCardDuration)}s", color = TextSecondary, fontSize = 11.sp)
                                Slider(
                                    value = endCardDuration,
                                    onValueChange = { endCardDuration = it },
                                    valueRange = 1.0f..5.0f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = StudioAccentLime,
                                        activeTrackColor = StudioAccentLime
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bottom Primary Action: Deploy / Go to Export Preview
                Button(
                    onClick = onGoToExport,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("video_editor_export_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioAccentLime,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Export & Deploy Video Ad →", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                videoViewRef?.stopPlayback()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }
}

