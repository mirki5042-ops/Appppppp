package com.example.data.remote

import android.content.Context
import android.media.MediaMetadataRetriever
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

/** Real Veo 3.1 Lite client. There is intentionally no stock-video or simulated-video fallback. */
class VideoGenerationService(
    private val modelName: String = VEO_MODEL
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(75, TimeUnit.SECONDS)
        .writeTimeout(75, TimeUnit.SECONDS)
        .callTimeout(90, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    /**
     * Produces one authentic, 8-second, 720p portrait video using Veo's long-running operation API.
     * If imageUri is supplied, the product photograph is used as the initial-frame identity anchor.
     */
    suspend fun generateWithVeo(
        context: Context,
        prompt: String,
        imageUri: String?,
        onStatus: (String) -> Unit = {}
    ): File = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY.trim()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            throw IllegalStateException(
                "Veo is not configured. Add a valid GEMINI_API_KEY to the project's .env/AI Studio secrets, then rebuild."
            )
        }
        if (prompt.isBlank()) throw IllegalArgumentException("The final Veo prompt is empty. Rebuild the ad plan before generating.")

        val inputImage = imageUri?.takeIf { it.isNotBlank() }?.let { encodeProductImage(context, it) }
        val instance = JSONObject().apply {
            put("prompt", prompt)
            if (inputImage != null) {
                // Veo's REST Image object uses imageBytes + mimeType (not Gemini inlineData).
                put("image", JSONObject().apply {
                    put("imageBytes", inputImage.second)
                    put("mimeType", inputImage.first)
                })
            }
        }
        val parameters = JSONObject().apply {
            put("aspectRatio", "9:16")
            put("durationSeconds", "8")
            put("resolution", "720p")
            put("numberOfVideos", 1)
            // The API requires allow_adult for image-to-video input and allow_all for text-to-video.
            put("personGeneration", if (inputImage != null) "allow_adult" else "allow_all")
        }
        val payload = JSONObject().apply {
            put("instances", JSONArray().put(instance))
            put("parameters", parameters)
        }

        onStatus("Submitting your 8-second ad to Veo 3.1 Lite…")
        val startResponse = executeJson(
            Request.Builder()
                .url("$GEMINI_BASE_URL/models/$modelName:predictLongRunning")
                .header("x-goog-api-key", apiKey)
                .header("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build(),
            "Veo video generation"
        )
        val operationName = startResponse.optString("name").takeIf { it.isNotBlank() }
            ?: throw IOException("Veo accepted no operation ID. Please try generating the ad again.")

        val deadline = System.currentTimeMillis() + MAX_OPERATION_MILLIS
        var pollCount = 0
        var completedOperation: JSONObject? = null
        while (System.currentTimeMillis() < deadline) {
            delay(POLL_INTERVAL_MS)
            pollCount++
            onStatus(when {
                pollCount < 3 -> "Veo is composing the shots and synchronised audio…"
                pollCount < 8 -> "Rendering product movement, lighting, and scene cuts…"
                else -> "Finishing the video render. This can take several minutes…"
            })

            val operationUrl = "$GEMINI_BASE_URL/${operationName.trimStart('/')}"
            val operation = executeJson(
                Request.Builder()
                    .url(operationUrl)
                    .header("x-goog-api-key", apiKey)
                    .get()
                    .build(),
                "Veo render status"
            )
            if (operation.optBoolean("done", false)) {
                completedOperation = operation
                break
            }
        }

        val result = completedOperation
            ?: throw IOException("Veo is still processing after several minutes. No local video was saved; you can retry later.")

        val apiError = result.optJSONObject("error")
        if (apiError != null) {
            val message = apiError.optString("message", "Veo could not complete this request.")
            throw IOException("Veo couldn't generate this ad. $message")
        }

        val videoUri = extractVideoUri(result)
            ?: throw IOException("Veo completed without a downloadable video. Please retry with a simpler brief or a different product image.")

        onStatus("Downloading the finished video to this device…")
        val outputDirectory = File(context.filesDir, "generated_ads").apply { mkdirs() }
        val tempFile = File(outputDirectory, "veo_${UUID.randomUUID()}.mp4.part")
        val outputFile = File(tempFile.parentFile, tempFile.name.removeSuffix(".part"))
        try {
            val request = Request.Builder()
                .url(videoUri)
                .header("x-goog-api-key", apiKey)
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val details = response.body?.string().orEmpty().take(500)
                    throw IOException("Veo generated the video, but download failed (HTTP ${response.code}). ${details}")
                }
                val body = response.body ?: throw IOException("Veo returned an empty video file.")
                FileOutputStream(tempFile).use { output -> body.byteStream().use { input -> input.copyTo(output) } }
            }
            if (!tempFile.exists() || tempFile.length() < MIN_VIDEO_BYTES) {
                throw IOException("Veo returned an incomplete video file. Please retry.")
            }
            if (!tempFile.renameTo(outputFile)) {
                tempFile.copyTo(outputFile, overwrite = true)
                tempFile.delete()
            }
            validateRenderedVideo(outputFile)
            Log.i(TAG, "Veo video saved locally (${outputFile.length()} bytes)")
            outputFile
        } catch (e: Exception) {
            tempFile.delete()
            outputFile.delete()
            throw e
        }
    }

    /** Copies picker images into private app storage so Veo can still use them after plan review. */
    fun persistProductImage(context: Context, sourceUri: Uri): Uri {
        val input = when (sourceUri.scheme) {
            "file" -> sourceUri.path?.let { FileInputStream(File(it)) }
            else -> context.contentResolver.openInputStream(sourceUri)
        } ?: throw IOException("The selected product photo could not be opened. Choose another image.")

        val bitmap = input.use { BitmapFactory.decodeStream(it) }
            ?: throw IOException("The selected file is not a supported image. Choose a JPG or PNG photo.")
        val resized = resizeForVeo(bitmap, MAX_IMAGE_EDGE)
        val dir = File(context.filesDir, "product_images").apply { mkdirs() }
        val destination = File(dir, "product_${UUID.randomUUID()}.jpg")
        FileOutputStream(destination).use { output ->
            if (!resized.compress(Bitmap.CompressFormat.JPEG, 90, output)) {
                throw IOException("Could not save the selected product photo.")
            }
        }
        if (resized !== bitmap) resized.recycle()
        if (!bitmap.isRecycled) bitmap.recycle()
        return Uri.fromFile(destination)
    }

    private fun encodeProductImage(context: Context, source: String): Pair<String, String> {
        val uri = Uri.parse(source)
        val stream = when (uri.scheme) {
            "file" -> uri.path?.let { FileInputStream(File(it)) }
            else -> context.contentResolver.openInputStream(uri)
        } ?: throw IOException("The product photo is no longer available. Reattach it on the creation screen.")

        val bitmap = stream.use { BitmapFactory.decodeStream(it) }
            ?: throw IOException("Veo could not read the product photo. Choose a JPG or PNG image.")
        val resized = resizeForVeo(bitmap, MAX_IMAGE_EDGE)
        val bytes = java.io.ByteArrayOutputStream().use { output ->
            resized.compress(Bitmap.CompressFormat.JPEG, 88, output)
            output.toByteArray()
        }
        if (resized !== bitmap) resized.recycle()
        if (!bitmap.isRecycled) bitmap.recycle()
        if (bytes.size > MAX_IMAGE_BYTES) {
            throw IOException("The product photo is too large to send to Veo. Choose a smaller image.")
        }
        return "image/jpeg" to Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun resizeForVeo(source: Bitmap, maxEdge: Int): Bitmap {
        val largest = maxOf(source.width, source.height)
        if (largest <= maxEdge) return source
        val scale = maxEdge.toFloat() / largest.toFloat()
        return Bitmap.createScaledBitmap(
            source,
            (source.width * scale).toInt().coerceAtLeast(1),
            (source.height * scale).toInt().coerceAtLeast(1),
            true
        )
    }

    private fun validateRenderedVideo(file: File) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(file.absolutePath)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?: throw IOException("The generated file has no readable video duration.")
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
            if (durationMs !in 6_000L..10_000L) {
                throw IOException("Veo returned a video outside the expected 8-second runtime (${durationMs / 1000.0}s). Please retry; this render was not counted.")
            }
            if (width != null && height != null && height <= width) {
                throw IOException("Veo returned a landscape video instead of 9:16 portrait (${width}x${height}). Please retry; this render was not counted.")
            }
        } catch (e: IOException) {
            throw e
        } catch (e: Exception) {
            throw IOException("The downloaded MP4 could not be verified as a playable portrait video. Please retry.", e)
        } finally {
            try { retriever.release() } catch (_: Exception) { }
        }
    }

    private fun executeJson(request: Request, operationLabel: String): JSONObject {
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val root = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
                val details = root.optJSONObject("error")?.optString("message").orEmpty()
                Log.e(TAG, "$operationLabel failed (${response.code}): $details")
                throw IOException(apiErrorMessage(response.code, details, operationLabel))
            }
            return try {
                JSONObject(body)
            } catch (e: Exception) {
                throw IOException("$operationLabel returned an unreadable response. Please retry.")
            }
        }
    }

    private fun extractVideoUri(operation: JSONObject): String? {
        val response = operation.optJSONObject("response") ?: return null
        val direct = response.optJSONObject("generateVideoResponse")
            ?.optJSONArray("generatedSamples")
            ?.optJSONObject(0)
            ?.optJSONObject("video")
            ?.optString("uri")
        if (!direct.isNullOrBlank() && direct != "null") return direct

        val sdkShape = response.optJSONArray("generatedVideos")
            ?.optJSONObject(0)
            ?.optJSONObject("video")
            ?.optString("uri")
        return sdkShape?.takeIf { it.isNotBlank() && it != "null" }
    }

    private fun apiErrorMessage(code: Int, details: String, label: String): String {
        val suffix = details.takeIf { it.isNotBlank() }?.let { " Details: $it" }.orEmpty()
        return when (code) {
            400 -> "$label rejected the request. Check that the prompt and image meet Veo's requirements.$suffix"
            401, 403 -> "$label API access was denied. Check GEMINI_API_KEY, project billing, and Veo access.$suffix"
            404 -> "$label endpoint or model was not found. Confirm the model ID is enabled for this API key.$suffix"
            429 -> "$label rate limit or quota was reached. Check the Gemini API rate limits and retry later.$suffix"
            in 500..599 -> "$label is temporarily unavailable. Retry in a moment.$suffix"
            else -> "$label failed (HTTP $code).$suffix"
        }
    }

    companion object {
        const val VEO_MODEL = "veo-3.1-lite-generate-preview"
        const val GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
        private const val MAX_OPERATION_MILLIS = 7 * 60 * 1000L
        private const val POLL_INTERVAL_MS = 10_000L
        private const val MAX_IMAGE_EDGE = 1024
        private const val MAX_IMAGE_BYTES = 5 * 1024 * 1024
        private const val MIN_VIDEO_BYTES = 10 * 1024L
        private const val TAG = "VeoVideoGeneration"
    }
}
