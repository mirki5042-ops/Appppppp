package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.repository.CampaignRepository
import com.example.ui.CampaignViewModel
import com.example.ui.Screen
import com.example.ui.screens.AgenticProgressScreen
import com.example.ui.screens.ExportPreviewScreen
import com.example.ui.screens.CreateAdScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PlanningScreen
import com.example.ui.screens.VideoEditorScreen
import com.example.ui.theme.ProductAdStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val repository = CampaignRepository(database.campaignDao())

        setContent {
            ProductAdStudioTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val viewModel: CampaignViewModel = viewModel {
                        CampaignViewModel(repository, applicationContext)
                    }
                    ProductAdStudioApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun ProductAdStudioApp(viewModel: CampaignViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val campaigns by viewModel.campaigns.collectAsStateWithLifecycle()
    val selectedCampaign by viewModel.selectedCampaign.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val remainingGenerations by viewModel.remainingGenerations.collectAsStateWithLifecycle()
    val agenticSteps by viewModel.agenticSteps.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()
    val context = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearErrorMessage()
        }
    }

    when (currentScreen) {
        is Screen.Home -> HomeScreen(
            campaigns = campaigns,
            onSelectCampaign = { viewModel.selectCampaign(it) },
            onCreateNewClick = { viewModel.navigateTo(Screen.CreateAd) },
            onDeleteCampaign = { viewModel.deleteCampaign(it) }
        )

        is Screen.CreateAd -> CreateAdScreen(
            isWorking = isGenerating,
            remainingGenerations = remainingGenerations,
            onBack = { viewModel.navigateTo(Screen.Home) },
            onBuildPlan = { prompt, name, url, objective, style, imageUri, bitmap ->
                viewModel.buildCampaignPlan(prompt, name, url, objective, style, imageUri, bitmap)
            }
        )

        is Screen.AgenticProgress -> AgenticProgressScreen(steps = agenticSteps)

        is Screen.Planning -> {
            val campaign = selectedCampaign
            if (campaign != null) {
                PlanningScreen(
                    campaign = campaign,
                    onBack = { viewModel.navigateTo(Screen.Home) },
                    onApproveAndContinue = { viewModel.generateVideoFromPlan(it) }
                )
            } else {
                viewModel.navigateTo(Screen.Home)
            }
        }

        is Screen.VideoEditor -> {
            val campaign = selectedCampaign
            if (campaign != null) {
                VideoEditorScreen(
                    campaign = campaign,
                    onBack = { viewModel.navigateTo(Screen.Home) },
                    onSaveOverlays = { headline, cta, brand, hook, subtitle, ctaColor, textColor, endDur, endShow, showHook, showSub ->
                        viewModel.updateOverlays(headline, cta, brand, hook, subtitle, ctaColor, textColor, endDur, endShow, showHook, showSub)
                    },
                    onSwapFootage = { newUri, newImg -> viewModel.swapVideoFootage(newUri, newImg) },
                    onGoToExport = { viewModel.navigateTo(Screen.ExportPreview) }
                )
            } else {
                viewModel.navigateTo(Screen.Home)
            }
        }

        is Screen.ExportPreview -> {
            val campaign = selectedCampaign
            if (campaign != null) {
                ExportPreviewScreen(
                    campaign = campaign,
                    onBack = { viewModel.navigateTo(Screen.VideoEditor) }
                )
            } else {
                viewModel.navigateTo(Screen.Home)
            }
        }
    }
}
