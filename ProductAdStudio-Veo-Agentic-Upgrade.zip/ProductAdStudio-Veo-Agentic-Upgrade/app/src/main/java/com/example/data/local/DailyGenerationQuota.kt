package com.example.data.local

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local prototype quota: five successful Veo renders per device-local calendar day. */
class DailyGenerationQuota(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(
        "productad_daily_generation_quota",
        Context.MODE_PRIVATE
    )

    @Synchronized
    fun remaining(): Int = (DAILY_LIMIT - countForToday()).coerceAtLeast(0)

    @Synchronized
    fun canGenerate(): Boolean = countForToday() < DAILY_LIMIT

    /** Records only a successfully downloaded video; failed renders do not consume a slot. */
    @Synchronized
    fun recordSuccessfulGeneration(): Int {
        val nextCount = countForToday() + 1
        preferences.edit()
            .putString(KEY_DAY, todayKey())
            .putInt(KEY_COUNT, nextCount.coerceAtMost(DAILY_LIMIT))
            .apply()
        return (DAILY_LIMIT - nextCount).coerceAtLeast(0)
    }

    private fun countForToday(): Int {
        if (preferences.getString(KEY_DAY, null) != todayKey()) return 0
        return preferences.getInt(KEY_COUNT, 0).coerceIn(0, DAILY_LIMIT)
    }

    private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    companion object {
        const val DAILY_LIMIT = 5
        private const val KEY_DAY = "quota_day"
        private const val KEY_COUNT = "successful_generations"
    }
}
