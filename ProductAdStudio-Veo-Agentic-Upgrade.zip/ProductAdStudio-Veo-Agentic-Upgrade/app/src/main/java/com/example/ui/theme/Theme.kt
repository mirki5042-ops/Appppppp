package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StudioColorScheme = darkColorScheme(
    primary = StudioAccentLime,
    onPrimary = TextOnAccent,
    primaryContainer = StudioSurfaceElevated,
    onPrimaryContainer = StudioAccentLime,
    secondary = StudioAccentLavender,
    onSecondary = Color(0xFF1E1538),
    secondaryContainer = StudioSurfaceCard,
    onSecondaryContainer = StudioAccentLavender,
    tertiary = StudioAccentCyan,
    onTertiary = Color(0xFF032838),
    background = StudioBackground,
    onBackground = TextPrimary,
    surface = StudioSurface,
    onSurface = TextPrimary,
    surfaceVariant = StudioSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = StudioBorder,
    outlineVariant = StudioBorderHighlight
)

@Composable
fun ProductAdStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StudioColorScheme,
        typography = Typography,
        content = content
    )
}
