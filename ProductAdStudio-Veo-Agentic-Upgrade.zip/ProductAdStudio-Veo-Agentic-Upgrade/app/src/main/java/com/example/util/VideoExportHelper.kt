package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.local.CampaignEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

object VideoExportHelper {

    private const val TAG = "VideoExportHelper"

    /**
     * Resolves an InputStream for any video URI format (file, android.resource, content, raw)
     */
    fun openVideoInputStream(context: Context, videoUriString: String?): Pair<InputStream?, String> {
        val uriStr = videoUriString?.trim() ?: ""

        // Try direct file path
        if (uriStr.startsWith("file://") || uriStr.startsWith("/")) {
            val path = uriStr.removePrefix("file://")
            val file = File(path)
            if (file.exists() && file.length() > 0) {
                return Pair(file.inputStream(), file.name)
            }
        }

        // Try ContentResolver for content:// or android.resource://
        if (uriStr.isNotBlank()) {
            try {
                val uri = Uri.parse(uriStr)
                val stream = context.contentResolver.openInputStream(uri)
                if (stream != null) {
                    return Pair(stream, "campaign_ad_${System.currentTimeMillis()}.mp4")
                }
            } catch (e: Exception) {
                Log.w(TAG, "ContentResolver could not open $uriStr: ${e.message}")
            }
        }

        // A missing source is a real error. Never substitute a demo video into a user's export.
        return Pair(null, "missing_video.mp4")
    }

    /**
     * Saves the campaign MP4 video to the device's public Movies directory / MediaStore Gallery
     */
    suspend fun exportVideoToGallery(
        context: Context,
        campaign: CampaignEntity
    ): Result<Uri> = withContext(Dispatchers.IO) {
        try {
            val (inputStream, sourceFileName) = openVideoInputStream(context, campaign.importedVideoUri)
            if (inputStream == null) {
                return@withContext Result.failure(Exception("Cannot locate source video file"))
            }

            val sanitizedName = campaign.name
                .replace(Regex("[^a-zA-Z0-9_]"), "_")
                .take(30)
                .ifBlank { "ProductAd" }
            val fileName = "Ad_${sanitizedName}_${System.currentTimeMillis()}.mp4"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ProductAdStudio")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                    put(MediaStore.Video.Media.TITLE, campaign.headlineText)
                    put(MediaStore.Video.Media.DESCRIPTION, "${campaign.hookBadge} - ${campaign.ctaText}")
                }

                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
                    ?: return@withContext Result.failure(Exception("Failed to create MediaStore entry"))

                resolver.openOutputStream(uri)?.use { output ->
                    inputStream.use { input ->
                        input.copyTo(output)
                    }
                }

                contentValues.clear()
                contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, contentValues, null, null)

                return@withContext Result.success(uri)
            } else {
                // Pre-Android 10 public directory
                val moviesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                val targetDir = File(moviesDir, "ProductAdStudio").apply { mkdirs() }
                val targetFile = File(targetDir, fileName)

                FileOutputStream(targetFile).use { output ->
                    inputStream.use { input ->
                        input.copyTo(output)
                    }
                }

                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(targetFile.absolutePath),
                    arrayOf("video/mp4"),
                    null
                )

                return@withContext Result.success(Uri.fromFile(targetFile))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Export to gallery error", e)
            Result.failure(e)
        }
    }

    /**
     * Shares the campaign video file with any external app (TikTok, Instagram, WhatsApp, etc.) via FileProvider
     */
    suspend fun shareVideoFile(
        context: Context,
        campaign: CampaignEntity
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val (inputStream, _) = openVideoInputStream(context, campaign.importedVideoUri)
            if (inputStream == null) {
                return@withContext Result.failure(Exception("Cannot locate source video file"))
            }

            // Write to app cache so FileProvider can safely share it
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val sharedFile = File(exportDir, "ad_export_${campaign.id.take(8)}.mp4")

            FileOutputStream(sharedFile).use { output ->
                inputStream.use { input ->
                    input.copyTo(output)
                }
            }

            val authority = "${context.packageName}.fileprovider"
            val contentUri = FileProvider.getUriForFile(context, authority, sharedFile)

            val shareCaption = buildString {
                appendLine("🎬 ${campaign.hookBadge}")
                appendLine()
                appendLine(campaign.headlineText)
                if (campaign.subtitleText.isNotBlank()) {
                    appendLine(campaign.subtitleText)
                }
                appendLine()
                appendLine("👉 ${campaign.ctaText}")
                appendLine()
                appendLine("#${campaign.productName.replace(" ", "")} #AdCampaign #ProductAdStudio")
            }

            withContext(Dispatchers.Main) {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    putExtra(Intent.EXTRA_SUBJECT, campaign.headlineText)
                    putExtra(Intent.EXTRA_TEXT, shareCaption)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }

                val chooser = Intent.createChooser(intent, "Deploy Ad to TikTok, Reels & Shorts")
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(chooser)
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Share video error", e)
            Result.failure(e)
        }
    }

    /**
     * Copies complete commercial campaign copy package (Headline, Hook, Subtitle, CTA, Storyboard) to Clipboard
     */
    fun copyCampaignAdPackage(context: Context, campaign: CampaignEntity) {
        val packageText = buildString {
            appendLine("=== COMMERCIAL AD CAMPAIGN DECK ===")
            appendLine("Campaign: ${campaign.name}")
            appendLine("Product: ${campaign.productName}")
            appendLine("Objective: ${campaign.campaignObjective}")
            appendLine("Visual Style: ${campaign.visualStyle}")
            appendLine("Camera Motion: ${campaign.cameraMotion}")
            appendLine()
            appendLine("--- 5-PHASE AD NARRATIVE STRUCTURE ---")
            appendLine("1. Hook Eyebrow Badge: ${campaign.hookBadge}")
            appendLine("2. Main Hook Headline: ${campaign.headlineText}")
            appendLine("3. Sensory Metaphor / Value Subtitle: ${campaign.subtitleText}")
            appendLine("4. Call To Action: ${campaign.ctaText}")
            appendLine()
            if (!campaign.amplifiedPrompt.isNullOrBlank()) {
                appendLine("--- AI CINEMATOGRAPHY PROMPT ---")
                appendLine(campaign.amplifiedPrompt)
                appendLine()
            }
            if (!campaign.storyboardJson.isNullOrBlank()) {
                appendLine("--- SCENE STORYBOARD ---")
                appendLine(campaign.storyboardJson)
            }
        }

        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Commercial Ad Deck", packageText)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "📋 Full Campaign Ad Deck copied to clipboard!", Toast.LENGTH_SHORT).show()
    }
}
