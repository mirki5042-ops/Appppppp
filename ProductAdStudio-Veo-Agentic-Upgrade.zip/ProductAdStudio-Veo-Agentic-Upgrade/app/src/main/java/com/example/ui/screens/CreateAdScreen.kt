package com.example.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.remote.VideoGenerationService
import com.example.ui.theme.StudioAccentCyan
import com.example.ui.theme.StudioAccentLime
import com.example.ui.theme.StudioBackground
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurfaceCard
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

private val Objectives = listOf("Sales", "Product launch", "Awareness", "App installs")
private val VisualStyles = listOf("Luxury editorial", "Fresh & clinical", "High-energy", "Warm lifestyle", "Clean minimal")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateAdScreen(
    isWorking: Boolean,
    remainingGenerations: Int,
    onBack: () -> Unit,
    onBuildPlan: (
        prompt: String,
        productName: String,
        productUrl: String?,
        objective: String,
        style: String,
        imageUri: String?,
        bitmap: android.graphics.Bitmap?
    ) -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current

    var prompt by remember { mutableStateOf("") }
    var productName by remember { mutableStateOf("") }
    var productUrl by remember { mutableStateOf("") }
    var selectedObjective by remember { mutableStateOf("Sales") }
    var selectedStyle by remember { mutableStateOf("Luxury editorial") }
    var selectedImageUri by remember { mutableStateOf<String?>(null) }
    var selectedBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var imageError by remember { mutableStateOf<String?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                // Save into private app storage so the file remains available after plan review/restart.
                val savedUri = VideoGenerationService().persistProductImage(context, uri)
                selectedImageUri = savedUri.toString()
                selectedBitmap = savedUri.path?.let { BitmapFactory.decodeFile(it) }
                imageError = null
            } catch (error: Exception) {
                imageError = error.message ?: "Could not read that product photo. Try another image."
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("create_ad_back_button")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("PRODUCTAD STUDIO", color = StudioAccentLime, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                Text("Create a real ad", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Surface(
                color = StudioSurfaceElevated,
                contentColor = TextSecondary,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Movie, null, modifier = Modifier.size(14.dp), tint = StudioAccentLime)
                    Spacer(Modifier.width(6.dp))
                    Text("$remainingGenerations / 5 today", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Column(
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("From a simple brief\nto a campaign-ready ad.", color = TextPrimary, fontSize = 29.sp, lineHeight = 34.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "Tell the AI what you want to sell and what the viewer should feel or do. Specialist agents will shape the concept, script and storyboard before Veo renders the video.",
                    color = TextSecondary, fontSize = 13.sp, lineHeight = 19.sp
                )
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard),
                shape = RoundedCornerShape(22.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SectionNumber("01")
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Describe the ad", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Plain language is enough", color = TextMuted, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = StudioAccentLime, modifier = Modifier.size(21.dp))
                    }
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth().height(150.dp).testTag("campaign_brief_input"),
                        placeholder = {
                            Text("Example: Make a premium serum ad with icy blue glass, watery macro shots and a clean final product reveal. Focus on hydration; keep it elegant, not clinical.", color = TextMuted, fontSize = 13.sp, lineHeight = 18.sp)
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = fieldColors(),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary, lineHeight = 20.sp),
                        maxLines = 6
                    )
                    Text("Tip: mention the product, audience, main benefit, visual mood and desired action. Don’t add claims you can’t substantiate.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard),
                shape = RoundedCornerShape(22.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SectionNumber("02")
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Brand details", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Optional. Public page title/description may be used as unverified context.", color = TextMuted, fontSize = 11.sp)
                        }
                    }
                    OutlinedTextField(
                        value = productName,
                        onValueChange = { productName = it },
                        modifier = Modifier.fillMaxWidth().testTag("product_name_input"),
                        label = { Text("Product or brand name (optional)") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = fieldColors()
                    )
                    OutlinedTextField(
                        value = productUrl,
                        onValueChange = { productUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Product website (optional)") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = fieldColors()
                    )
                    if (selectedImageUri == null) {
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable {
                                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }.testTag("attach_product_photo_button"),
                            shape = RoundedCornerShape(16.dp),
                            color = StudioSurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
                        ) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(StudioBackground), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = StudioAccentCyan, modifier = Modifier.size(22.dp))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Add product photo", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text("Recommended for more accurate packaging and brand identity", color = TextMuted, fontSize = 11.sp, lineHeight = 15.sp)
                                }
                                Text("ADD", color = StudioAccentCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            }
                        }
                    } else {
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(StudioSurfaceElevated).padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncImage(model = selectedImageUri, contentDescription = "Selected product photo", modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Product photo attached", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("Veo will use it as the visual starting point", color = TextSecondary, fontSize = 11.sp)
                            }
                            IconButton(onClick = { selectedImageUri = null; selectedBitmap = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove product photo", tint = TextSecondary)
                            }
                        }
                    }
                    imageError?.let { Text(it, color = Color(0xFFFF8888), fontSize = 11.sp) }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard),
                shape = RoundedCornerShape(22.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SectionNumber("03")
                        Spacer(Modifier.width(10.dp))
                        Text("Choose the direction", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    Text("CAMPAIGN GOAL", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Objectives.forEach { option ->
                            FilterChip(
                                selected = selectedObjective == option,
                                onClick = { selectedObjective = option },
                                label = { Text(option, fontSize = 12.sp) },
                                leadingIcon = if (selectedObjective == option) ({ Icon(Icons.Default.Check, null, Modifier.size(14.dp)) }) else null,
                                colors = chipColors()
                            )
                        }
                    }
                    Text("VISUAL STYLE", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        VisualStyles.forEach { option ->
                            FilterChip(
                                selected = selectedStyle == option,
                                onClick = { selectedStyle = option },
                                label = { Text(option, fontSize = 12.sp) },
                                leadingIcon = if (selectedStyle == option) ({ Icon(Icons.Default.Check, null, Modifier.size(14.dp)) }) else null,
                                colors = chipColors()
                            )
                        }
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Movie, null, tint = StudioAccentLime, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("VIDEO OUTPUT", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        SpecPill("9:16 PORTRAIT")
                        SpecPill("8 SECONDS")
                        SpecPill("720P HD")
                    }
                    Text("Google Veo 3.1 Lite · native audio · multi-shot ad prompt", color = TextSecondary, fontSize = 11.sp)
                    Text("Video render estimate: about \$0.40 per successful 8-second 720p video at Google's listed rate, before tax/FX. Video generation is not on the free tier.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            Spacer(Modifier.height(4.dp))
        }

        Surface(color = StudioBackground, shadowElevation = 8.dp) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Button(
                    onClick = {
                        onBuildPlan(
                            prompt.trim(), productName.trim(), productUrl.trim().ifBlank { null },
                            selectedObjective, selectedStyle, selectedImageUri, selectedBitmap
                        )
                    },
                    enabled = !isWorking && prompt.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(54.dp).testTag("build_ad_plan_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioAccentLime, contentColor = Color(0xFF10130C), disabledContainerColor = StudioSurfaceElevated, disabledContentColor = TextMuted),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    if (isWorking) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF10130C))
                        Spacer(Modifier.width(9.dp))
                        Text("Building your campaign plan…", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    } else {
                        Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(9.dp))
                        Text("Build my ad plan", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
                Text(
                    if (remainingGenerations > 0) "Plan first. Review concept, script and storyboard. Render only after approval." else "You've used all five renders today. You can still prepare a plan; Veo rendering resumes after the local daily reset.",
                    modifier = Modifier.fillMaxWidth(), color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp
                )
            }
        }
    }
}

@Composable
private fun SectionNumber(number: String) {
    Box(Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(StudioSurfaceElevated).border(1.dp, StudioBorder, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
        Text(number, color = StudioAccentLime, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
private fun SpecPill(text: String) {
    Surface(color = StudioBackground, shape = RoundedCornerShape(8.dp), border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)) {
        Text(text, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp), color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.4.sp)
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = StudioAccentLime,
    unfocusedBorderColor = StudioBorder,
    focusedLabelColor = StudioAccentLime,
    unfocusedLabelColor = TextMuted,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    cursorColor = StudioAccentLime,
    focusedContainerColor = StudioBackground,
    unfocusedContainerColor = StudioBackground
)

@Composable
private fun chipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = StudioAccentLime,
    selectedLabelColor = Color(0xFF10130C),
    selectedLeadingIconColor = Color(0xFF10130C),
    containerColor = StudioSurfaceElevated,
    labelColor = TextSecondary,
    iconColor = TextSecondary
)
