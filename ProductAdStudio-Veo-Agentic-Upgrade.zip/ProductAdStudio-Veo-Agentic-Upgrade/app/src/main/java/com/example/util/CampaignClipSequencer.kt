package com.example.util

import android.content.Context
import com.example.data.local.CampaignEntity

/** The current Veo flow generates one complete 8-second ad, not separate editable source clips. */
data class SceneClip(
    val sceneNumber: Int,
    val phaseName: String,
    val title: String,
    val cameraAngle: String,
    val videoUri: String,
    val imageDrawableRes: String,
    val hookBadge: String,
    val headline: String,
    val subtitle: String,
    val ctaText: String,
    val timingLabel: String
)

object CampaignClipSequencer {
    /** Return the actual rendered MP4 as one clip; never substitute a bundled demo based on keywords. */
    @Suppress("UNUSED_PARAMETER")
    fun getScenesForCampaign(context: Context, campaign: CampaignEntity): List<SceneClip> {
        return listOf(
            SceneClip(
                sceneNumber = 1,
                phaseName = "Generated Veo commercial",
                title = "Complete Ad",
                cameraAngle = "9:16 · 720p · 8 seconds",
                videoUri = campaign.importedVideoUri.orEmpty(),
                imageDrawableRes = campaign.productImageUri.orEmpty(),
                hookBadge = campaign.hookBadge,
                headline = campaign.headlineText,
                subtitle = campaign.subtitleText,
                ctaText = campaign.ctaText,
                timingLabel = "0.0s–8.0s"
            )
        )
    }
}
