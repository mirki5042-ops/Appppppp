package com.example.ui.components

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import android.widget.VideoView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import java.io.File

@Composable
fun VideoPlayerView(
    videoUriString: String?,
    playlistUris: List<String> = emptyList(),
    currentSceneIndex: Int = 0,
    isMontageMode: Boolean = false,
    onSceneAdvanced: (Int) -> Unit = {},
    fallbackImageUri: String? = null,
    isMuted: Boolean = false,
    onPlayerReady: (MediaPlayer, VideoView) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    var videoViewRef by remember { mutableStateOf<VideoView?>(null) }
    var mediaPlayerRef by remember { mutableStateOf<MediaPlayer?>(null) }
    var currentlyLoadedUri by remember { mutableStateOf<String?>(null) }
    var lastMutedState by remember { mutableStateOf(isMuted) }
    var internalSceneIndex by remember { mutableIntStateOf(currentSceneIndex) }

    // Determine the active video URI
    val activeUri = if (isMontageMode && playlistUris.isNotEmpty()) {
        val safeIndex = internalSceneIndex.coerceIn(0, playlistUris.size - 1)
        playlistUris[safeIndex]
    } else if (!videoUriString.isNullOrBlank()) {
        videoUriString
    } else if (playlistUris.isNotEmpty()) {
        playlistUris[currentSceneIndex.coerceIn(0, playlistUris.size - 1)]
    } else {
        null
    }

    // Keep internalSceneIndex in sync if external currentSceneIndex changes
    if (!isMontageMode && internalSceneIndex != currentSceneIndex) {
        internalSceneIndex = currentSceneIndex
    }

    Box(modifier = modifier) {
        // High-definition photorealistic product visual backdrop
        if (!fallbackImageUri.isNullOrBlank()) {
            AsyncImage(
                model = fallbackImageUri,
                contentDescription = "Ad Visual",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        // Real Video Player Layer
        AndroidView(
            factory = { ctx ->
                VideoView(ctx).apply {
                    setZOrderOnTop(false)
                    setZOrderMediaOverlay(false)
                    videoViewRef = this
                    if (!activeUri.isNullOrBlank()) {
                        currentlyLoadedUri = activeUri
                        setupAndPlayVideo(
                            context = ctx,
                            videoView = this,
                            rawUriString = activeUri,
                            isMuted = isMuted,
                            isMontageMode = isMontageMode,
                            playlistUris = playlistUris,
                            getCurrentIndex = { internalSceneIndex },
                            onNextScene = { nextIdx ->
                                internalSceneIndex = nextIdx
                                onSceneAdvanced(nextIdx)
                            },
                            onPrepared = { mp ->
                                mediaPlayerRef = mp
                                onPlayerReady(mp, this)
                            }
                        )
                    }
                }
            },
            update = { view ->
                // ONLY reload media if target URI changed
                if (activeUri != currentlyLoadedUri && !activeUri.isNullOrBlank()) {
                    currentlyLoadedUri = activeUri
                    setupAndPlayVideo(
                        context = view.context,
                        videoView = view,
                        rawUriString = activeUri,
                        isMuted = isMuted,
                        isMontageMode = isMontageMode,
                        playlistUris = playlistUris,
                        getCurrentIndex = { internalSceneIndex },
                        onNextScene = { nextIdx ->
                            internalSceneIndex = nextIdx
                            onSceneAdvanced(nextIdx)
                        },
                        onPrepared = { mp ->
                            mediaPlayerRef = mp
                            onPlayerReady(mp, view)
                        }
                    )
                } else if (isMuted != lastMutedState) {
                    // Update volume without restarting video stream
                    lastMutedState = isMuted
                    mediaPlayerRef?.let { mp ->
                        try {
                            if (isMuted) mp.setVolume(0f, 0f) else mp.setVolume(1f, 1f)
                        } catch (e: Exception) {
                            Log.w("VideoPlayerView", "Volume update notice: ${e.message}")
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    }

    DisposableEffect(activeUri) {
        onDispose {
            try {
                videoViewRef?.stopPlayback()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }
}

fun resolveVideoUri(context: Context, rawUriString: String?): Uri? {
    if (rawUriString.isNullOrBlank()) return null
    return try {
        when {
            rawUriString.startsWith("file://") ->
                Uri.fromFile(File(rawUriString.removePrefix("file://")))
            rawUriString.startsWith("/") ->
                Uri.fromFile(File(rawUriString))
            else ->
                Uri.parse(rawUriString)
        }
    } catch (e: Exception) {
        Log.e("VideoPlayerView", "URI resolution failed: ${e.message}")
        null
    }
}

private fun setupAndPlayVideo(
    context: Context,
    videoView: VideoView,
    rawUriString: String?,
    isMuted: Boolean,
    isMontageMode: Boolean = false,
    playlistUris: List<String> = emptyList(),
    getCurrentIndex: () -> Int = { 0 },
    onNextScene: (Int) -> Unit = {},
    onPrepared: (MediaPlayer) -> Unit
) {
    if (rawUriString.isNullOrBlank()) return

    try {
        videoView.setOnErrorListener { _, what, extra ->
            Log.w("VideoPlayerView", "Playback notice ($what, $extra)")
            true
        }

        videoView.setOnCompletionListener { mp ->
            try {
                if (isMontageMode && playlistUris.size > 1) {
                    val next = (getCurrentIndex() + 1) % playlistUris.size
                    onNextScene(next)
                    val nextUri = playlistUris[next]
                    val parsed = resolveVideoUri(context, nextUri)
                    if (parsed != null) {
                        videoView.setVideoURI(parsed)
                        videoView.start()
                    } else {
                        mp.seekTo(0)
                        mp.start()
                    }
                } else {
                    mp.seekTo(0)
                    mp.start()
                }
            } catch (e: Exception) {
                Log.w("VideoPlayerView", "Loop error: ${e.message}")
            }
        }

        videoView.setOnPreparedListener { mp ->
            try {
                if (isMuted) mp.setVolume(0f, 0f) else mp.setVolume(1f, 1f)
                mp.isLooping = !isMontageMode || playlistUris.size <= 1
                videoView.start()
                onPrepared(mp)
            } catch (e: Exception) {
                Log.e("VideoPlayerView", "Error on prepared listener", e)
            }
        }

        val uri = resolveVideoUri(context, rawUriString)
        if (uri != null) {
            videoView.setVideoURI(uri)
        }
    } catch (e: Exception) {
        Log.e("VideoPlayerView", "VideoView setup error: ${e.message}")
    }
}
