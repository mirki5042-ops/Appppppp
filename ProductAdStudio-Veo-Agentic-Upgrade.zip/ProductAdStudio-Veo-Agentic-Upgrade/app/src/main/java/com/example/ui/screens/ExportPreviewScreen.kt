package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.widget.VideoView
import com.example.ui.components.VideoPlayerView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CampaignEntity
import com.example.ui.theme.StudioAccentCyan
import com.example.ui.theme.StudioAccentLime
import com.example.ui.theme.StudioAccentRose
import com.example.ui.theme.StudioBackground
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurfaceCard
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.CampaignClipSequencer
import com.example.util.VideoExportHelper
import kotlinx.coroutines.launch

@Composable
fun ExportPreviewScreen(
    campaign: CampaignEntity,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isPlaying by remember { mutableStateOf(true) }
    var videoViewRef by remember { mutableStateOf<VideoView?>(null) }
    var isExportingToGallery by remember { mutableStateOf(false) }
    var isSharingVideo by remember { mutableStateOf(false) }
    var exportSuccessMessage by remember { mutableStateOf<String?>(null) }

    // Multi-Scene Clipping Sequencer
    val scenes = remember(campaign) { CampaignClipSequencer.getScenesForCampaign(context, campaign) }
    val playlistUris = remember(scenes) { scenes.map { it.videoUri } }

    var isMontageMode by remember { mutableStateOf(true) }
    var activeSceneIndex by remember { mutableIntStateOf(0) }

    val currentScene = scenes.getOrElse(activeSceneIndex) { scenes.first() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("export_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Commercial Ad Export",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = if (scenes.size == 1) "Complete Veo MP4" else if (isMontageMode) "Full campaign montage" else "Scene ${activeSceneIndex + 1}: ${currentScene.title}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = StudioAccentLime,
                        fontSize = 11.sp
                    )
                )
            }

            Spacer(modifier = Modifier.size(48.dp))
        }

        // Multi-Scene Clipping Timeline Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = isMontageMode,
                onClick = { isMontageMode = true },
                label = { Text("🎬 Full Ad", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = StudioAccentLime,
                    selectedLabelColor = Color.Black,
                    containerColor = StudioSurfaceElevated,
                    labelColor = TextSecondary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    borderColor = if (isMontageMode) StudioAccentLime else StudioBorder,
                    enabled = true,
                    selected = isMontageMode
                )
            )

            if (scenes.size > 1) scenes.forEachIndexed { idx, sc ->
                FilterChip(
                    selected = !isMontageMode && activeSceneIndex == idx,
                    onClick = {
                        isMontageMode = false
                        activeSceneIndex = idx
                    },
                    label = { Text("Scene ${idx + 1}", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = StudioAccentCyan,
                        selectedLabelColor = Color.Black,
                        containerColor = StudioSurfaceElevated,
                        labelColor = TextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = if (!isMontageMode && activeSceneIndex == idx) StudioAccentCyan else StudioBorder,
                        enabled = true,
                        selected = !isMontageMode && activeSceneIndex == idx
                    )
                )
            }
        }

        // Full 9:16 Vertical Commercial Canvas with Multi-Clip Sync
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxSize()
                    .aspectRatio(9f / 16f, matchHeightConstraintsFirst = true)
                    .clip(RoundedCornerShape(22.dp))
                    .border(2.dp, if (isMontageMode) StudioAccentLime else StudioAccentCyan, RoundedCornerShape(22.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.Black)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable {
                            videoViewRef?.let { vv ->
                                try {
                                    if (vv.isPlaying) {
                                        vv.pause()
                                        isPlaying = false
                                    } else {
                                        vv.start()
                                        isPlaying = true
                                    }
                                } catch (e: Exception) {
                                    // Ignore
                                }
                            }
                        }
                ) {
                    // Video Player Layer
                    VideoPlayerView(
                        videoUriString = if (!isMontageMode) playlistUris.getOrNull(activeSceneIndex) else null,
                        playlistUris = playlistUris,
                        currentSceneIndex = activeSceneIndex,
                        isMontageMode = isMontageMode,
                        onSceneAdvanced = { nextIndex ->
                            activeSceneIndex = nextIndex
                        },
                        fallbackImageUri = campaign.productImageUri,
                        isMuted = false,
                        onPlayerReady = { _, vv ->
                            videoViewRef = vv
                            isPlaying = true
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Cinematic Gradient Vignette
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Black.copy(alpha = 0.55f),
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.8f)
                                    )
                                )
                            )
                    )

                    // Top Brand Badge & Clipping Time Pill
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                            .align(Alignment.TopCenter),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(StudioAccentLime)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = campaign.brandName.uppercase(),
                                    color = TextPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                )
                            }
                        }

                        // Scene Tag Pill
                        Surface(
                            color = StudioSurfaceElevated.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
                        ) {
                            Text(
                                text = if (scenes.size == 1) "FULL AD · 8S" else if (isMontageMode) "CLIP ${activeSceneIndex + 1}/${scenes.size} · ${currentScene.timingLabel}" else currentScene.timingLabel,
                                color = StudioAccentLime,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Bottom Dynamic Ad Overlays
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 14.dp, vertical = 18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Hook Badge
                        if (campaign.showHookBadge) {
                            val badgeText = if (isMontageMode && activeSceneIndex > 0) currentScene.hookBadge else campaign.hookBadge
                            Surface(
                                color = Color.Black.copy(alpha = 0.85f),
                                shape = RoundedCornerShape(14.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, StudioAccentLime.copy(alpha = 0.8f))
                            ) {
                                Text(
                                    text = badgeText,
                                    color = StudioAccentLime,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        // Headline
                        val displayHeadline = if (isMontageMode && activeSceneIndex > 0) currentScene.headline else campaign.headlineText
                        Text(
                            text = displayHeadline,
                            color = Color(campaign.textColorHex),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center,
                            lineHeight = 21.sp
                        )

                        // Subtitle
                        if (campaign.showSubtitle) {
                            val displaySub = if (isMontageMode && activeSceneIndex > 0) currentScene.subtitle else campaign.subtitleText
                            if (displaySub.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = displaySub,
                                    color = Color(0xFFD1D5DB),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 6.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // High-Converting CTA Button
                        Surface(
                            color = Color(campaign.ctaColorHex),
                            shape = RoundedCornerShape(22.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = campaign.ctaText,
                                    color = Color.Black,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Notification banner if video was saved
        if (exportSuccessMessage != null) {
            Surface(
                color = StudioAccentLime.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioAccentLime),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StudioAccentLime)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = exportSuccessMessage ?: "",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Bottom Export Deck
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard),
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Export/share saves the original Veo MP4. Editor text and color controls are currently preview-only and are not burned into the file.",
                    color = TextMuted,
                    fontSize = 10.sp,
                    lineHeight = 15.sp
                )

                // Primary Action: Save the actual source MP4 to Device Gallery
                Button(
                    onClick = {
                        if (!isExportingToGallery) {
                            isExportingToGallery = true
                            exportSuccessMessage = null
                            coroutineScope.launch {
                                val result = VideoExportHelper.exportVideoToGallery(context, campaign)
                                isExportingToGallery = false
                                result.onSuccess {
                                    exportSuccessMessage = "Video ad MP4 successfully saved to Gallery (Movies/ProductAdStudio)!"
                                    Toast.makeText(context, "✅ Ad saved to Gallery!", Toast.LENGTH_LONG).show()
                                }.onFailure { e ->
                                    Toast.makeText(context, "Export error: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("export_save_gallery_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioAccentLime,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(25.dp)
                ) {
                    if (isExportingToGallery) {
                        CircularProgressIndicator(
                            color = Color.Black,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Saving the 720p MP4…", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    } else {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save MP4 Video to Gallery", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }

                // Secondary Action: Real File Sharing via FileProvider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (!isSharingVideo) {
                                isSharingVideo = true
                                coroutineScope.launch {
                                    val result = VideoExportHelper.shareVideoFile(context, campaign)
                                    isSharingVideo = false
                                    result.onFailure { e ->
                                        Toast.makeText(context, "Share error: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("share_export_ad_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StudioSurfaceElevated,
                            contentColor = StudioAccentCyan
                        ),
                        shape = RoundedCornerShape(23.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Deploy Video Ad", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            VideoExportHelper.copyCampaignAdPackage(context, campaign)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp),
                        shape = RoundedCornerShape(23.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = TextPrimary
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy Ad Deck", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                videoViewRef?.stopPlayback()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }
}
