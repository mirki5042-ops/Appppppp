package com.example.ui

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CampaignEntity
import com.example.data.local.DailyGenerationQuota
import com.example.data.remote.AgenticStep
import com.example.data.remote.GeminiPlanningService
import com.example.data.remote.VideoGenerationService
import com.example.data.repository.CampaignRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

sealed class Screen {
    object Home : Screen()
    object CreateAd : Screen()
    object AgenticProgress : Screen()
    object Planning : Screen()
    object VideoEditor : Screen()
    object ExportPreview : Screen()
}

class CampaignViewModel(
    repository: CampaignRepository,
    context: Context,
    private val planningService: GeminiPlanningService = GeminiPlanningService(),
    private val videoGenerationService: VideoGenerationService = VideoGenerationService()
) : ViewModel() {

    private val appContext = context.applicationContext
    private val repository = repository
    private val dailyQuota = DailyGenerationQuota(appContext)

    val campaigns: StateFlow<List<CampaignEntity>> = repository.allCampaigns
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _selectedCampaignId = MutableStateFlow<String?>(null)
    val selectedCampaignId: StateFlow<String?> = _selectedCampaignId.asStateFlow()

    private val _selectedCampaign = MutableStateFlow<CampaignEntity?>(null)
    val selectedCampaign: StateFlow<CampaignEntity?> = _selectedCampaign.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _agenticSteps = MutableStateFlow<List<AgenticStep>>(emptyList())
    val agenticSteps: StateFlow<List<AgenticStep>> = _agenticSteps.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _remainingGenerations = MutableStateFlow(dailyQuota.remaining())
    val remainingGenerations: StateFlow<Int> = _remainingGenerations.asStateFlow()

    init {
        // Older builds inserted fabricated preset videos into Room. Remove only those demo rows.
        viewModelScope.launch { repository.deleteBundledPresets() }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
        if (screen == Screen.CreateAd) _remainingGenerations.value = dailyQuota.remaining()
    }

    fun selectCampaign(campaign: CampaignEntity) {
        _selectedCampaignId.value = campaign.id
        _selectedCampaign.value = campaign
        _currentScreen.value = if (campaign.importedVideoUri.isNullOrBlank()) Screen.Planning else Screen.VideoEditor
    }

    /** Runs the five creative specialists and saves a reviewable plan. No video is faked or rendered yet. */
    fun buildCampaignPlan(
        prompt: String,
        productName: String,
        productUrl: String?,
        objective: String,
        visualStyle: String,
        productImageUri: String?,
        productBitmap: Bitmap?
    ) {
        if (_isGenerating.value) return
        if (prompt.isBlank()) {
            _errorMessage.value = "Describe the ad you want first."
            return
        }
        // Users can still draft/revise plans after using their five renders. The limit only blocks Veo.
        _remainingGenerations.value = dailyQuota.remaining()

        viewModelScope.launch {
            _isGenerating.value = true
            _currentScreen.value = Screen.AgenticProgress
            _agenticSteps.value = emptyList()
            try {
                val plan = planningService.generateCompleteAdPlan(
                    prompt = prompt,
                    productName = productName,
                    productUrl = productUrl,
                    objective = objective,
                    visualStyle = visualStyle,
                    targetDuration = 8,
                    productBitmap = productBitmap,
                    onAgentStepUpdate = { steps -> _agenticSteps.value = steps }
                )

                val id = UUID.randomUUID().toString()
                val campaign = CampaignEntity(
                    id = id,
                    name = if (productName.isNotBlank()) "$productName · Ad" else plan.suggestedHeadline,
                    prompt = prompt.trim(),
                    productName = productName.trim().ifBlank { "Untitled product" },
                    productUrl = productUrl,
                    campaignObjective = objective,
                    visualStyle = visualStyle,
                    targetDuration = 8,
                    cameraMotion = "Agent-directed multi-shot edit",
                    lightingStyle = "Agent-directed",
                    aspectRatio = "9:16",
                    status = "PLAN_READY",
                    currentStage = 5,
                    productImageUri = productImageUri,
                    importedVideoUri = null,
                    amplifiedPrompt = plan.flowPrompt,
                    summaryJson = plan.summaryJson,
                    factsJson = plan.factsJson,
                    creativeDirectionJson = plan.creativeDirectionJson,
                    scriptJson = plan.scriptJson,
                    storyboardJson = plan.storyboardJson,
                    flowPrompt = plan.flowPrompt,
                    hookBadge = plan.hookBadge,
                    headlineText = plan.suggestedHeadline,
                    subtitleText = plan.subtitleText,
                    ctaText = plan.suggestedCta,
                    brandName = productName.trim().ifBlank { "Your brand" },
                    showHookBadge = true,
                    showSubtitle = plan.subtitleText.isNotBlank(),
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis()
                )
                repository.saveCampaign(campaign)
                _selectedCampaignId.value = campaign.id
                _selectedCampaign.value = campaign
                _currentScreen.value = Screen.Planning
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "The campaign plan could not be created. Please retry."
                _currentScreen.value = Screen.CreateAd
            } finally {
                _isGenerating.value = false
            }
        }
    }

    /** Generates a real Veo MP4 only after the user reviews and approves the creative plan. */
    fun generateVideoFromPlan(campaign: CampaignEntity) {
        if (_isGenerating.value) return
        if (!dailyQuota.canGenerate()) {
            _remainingGenerations.value = 0
            _errorMessage.value = "You've used all five video renders for today. The local daily limit resets tomorrow."
            return
        }
        val prompt = campaign.flowPrompt?.takeIf { it.isNotBlank() }
            ?: campaign.amplifiedPrompt?.takeIf { it.isNotBlank() }
        if (prompt.isNullOrBlank()) {
            _errorMessage.value = "This plan has no Veo prompt. Rebuild the plan before rendering."
            return
        }

        viewModelScope.launch {
            _isGenerating.value = true
            _currentScreen.value = Screen.AgenticProgress
            val steps = _agenticSteps.value.map { it.copy(isCompleted = true, isCurrent = false) }.toMutableList()
            steps += AgenticStep(
                "6 · Google Veo 3.1 Lite",
                "Submitting the approved multi-shot prompt and preparing a real MP4 render.",
                isCurrent = true
            )
            _agenticSteps.value = steps.toList()
            try {
                val outputFile: File = videoGenerationService.generateWithVeo(
                    context = appContext,
                    prompt = prompt,
                    imageUri = campaign.productImageUri,
                    onStatus = { message ->
                        val current = _agenticSteps.value.toMutableList()
                        if (current.isNotEmpty()) {
                            current[current.lastIndex] = current.last().copy(detail = message, isCurrent = true)
                            _agenticSteps.value = current
                        }
                    }
                )

                val remaining = dailyQuota.recordSuccessfulGeneration()
                _remainingGenerations.value = remaining
                val updated = campaign.copy(
                    status = "COMPLETED",
                    currentStage = 6,
                    importedVideoUri = Uri.fromFile(outputFile).toString(),
                    updatedAt = System.currentTimeMillis()
                )
                repository.saveCampaign(updated)
                _selectedCampaignId.value = updated.id
                _selectedCampaign.value = updated

                val completed = _agenticSteps.value.map { it.copy(isCompleted = true, isCurrent = false) }
                _agenticSteps.value = completed
                _currentScreen.value = Screen.VideoEditor
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Veo could not generate the video. Your plan has been saved so you can retry."
                _selectedCampaignId.value = campaign.id
                _selectedCampaign.value = campaign
                _currentScreen.value = Screen.Planning
            } finally {
                _isGenerating.value = false
            }
        }
    }

    fun updateOverlays(
        headline: String,
        ctaText: String,
        brandName: String,
        hookBadge: String,
        subtitleText: String,
        ctaColorHex: Long,
        textColorHex: Long,
        endCardDuration: Float,
        showEndCard: Boolean,
        showHookBadge: Boolean,
        showSubtitle: Boolean
    ) {
        val current = _selectedCampaign.value ?: return
        viewModelScope.launch {
            val updated = current.copy(
                headlineText = headline,
                ctaText = ctaText,
                brandName = brandName,
                hookBadge = hookBadge,
                subtitleText = subtitleText,
                ctaColorHex = ctaColorHex,
                textColorHex = textColorHex,
                endCardDurationSeconds = endCardDuration,
                showEndCard = showEndCard,
                showHookBadge = showHookBadge,
                showSubtitle = showSubtitle,
                updatedAt = System.currentTimeMillis()
            )
            repository.saveCampaign(updated)
            _selectedCampaign.value = updated
        }
    }

    fun swapVideoFootage(newUri: String, newProductImageUri: String? = null) {
        val current = _selectedCampaign.value ?: return
        viewModelScope.launch {
            val updated = current.copy(
                importedVideoUri = newUri,
                productImageUri = newProductImageUri ?: current.productImageUri,
                updatedAt = System.currentTimeMillis()
            )
            repository.saveCampaign(updated)
            _selectedCampaign.value = updated
        }
    }

    fun deleteCampaign(campaignId: String) {
        viewModelScope.launch {
            repository.deleteCampaign(campaignId)
            if (_selectedCampaignId.value == campaignId) {
                _selectedCampaignId.value = null
                _selectedCampaign.value = null
                _currentScreen.value = Screen.Home
            }
        }
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }
}
