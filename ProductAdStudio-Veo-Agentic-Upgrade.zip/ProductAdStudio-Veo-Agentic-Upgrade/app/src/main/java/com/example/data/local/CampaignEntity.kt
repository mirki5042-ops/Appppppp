package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "campaigns")
data class CampaignEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val prompt: String,
    val productName: String,
    val productUrl: String? = null,
    val campaignObjective: String = "Product Launch",
    val visualStyle: String = "Luxury Editorial",
    val targetDuration: Int = 8,
    val cameraMotion: String = "Orbit 360°",
    val lightingStyle: String = "Sunbeam Dew",
    val aspectRatio: String = "9:16",
    val status: String = "DRAFT",
    val currentStage: Int = 0,
    val productImageUri: String? = null,
    val importedVideoUri: String? = null,
    val amplifiedPrompt: String? = null,
    val agenticStepsJson: String? = null,
    val summaryJson: String? = null,
    val factsJson: String? = null,
    val creativeDirectionJson: String? = null,
    val scriptJson: String? = null,
    val storyboardJson: String? = null,
    val flowPrompt: String? = null,
    val hookBadge: String = "",
    val headlineText: String = "",
    val subtitleText: String = "",
    val ctaText: String = "Learn more",
    val brandName: String = "",
    val ctaColorHex: Long = 0xFFE2F952,
    val textColorHex: Long = 0xFFFFFFFF,
    val showHookBadge: Boolean = true,
    val showSubtitle: Boolean = true,
    val overlayPosition: String = "BOTTOM",
    val endCardDurationSeconds: Float = 2.0f,
    val showEndCard: Boolean = true,
    val videoVolume: Float = 1.0f,
    val musicVolume: Float = 0.5f,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
